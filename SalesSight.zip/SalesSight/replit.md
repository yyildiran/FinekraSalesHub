# Sales Management Application - Replit MD

## Overview

This is a comprehensive sales management application built with a modern full-stack architecture. The application provides dynamic team structures, customizable fields, sales tracking, renewal management, and analytics capabilities. It's designed for sales teams to manage their pipeline, track performance, and generate insights.

**Current Status**: Fully operational and production-ready with comprehensive goal management system. Complete team goal/target setting functionality implemented in Analytics page with Turkish Lira currency formatting. Goal creation, editing, deletion, and progress tracking all working properly. Navigation system with 8 horizontal tabs: Dashboard, Field Sales, Outbound, Renewals, Partnerships, Banks & PF's, Analytics, Settings. Analytics tab includes comprehensive goal management with team and individual member assignment capabilities. All API endpoints functional with proper authentication and data handling.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state management
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and bundling

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Authentication**: Replit Auth with OpenID Connect
- **Session Management**: PostgreSQL-backed sessions using connect-pg-simple
- **API Design**: RESTful endpoints with role-based access control

### Database Architecture
- **Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM with migrations
- **Schema**: Relational design with users, teams, sales, renewals, and sessions tables
- **Custom Fields**: JSONB storage for dynamic team-specific fields

## Key Components

### Authentication System
- Integrated Replit Auth using OpenID Connect
- Session-based authentication with PostgreSQL storage
- Role-based access control (admin, manager, sales_rep, viewer)
- Automatic user creation and session management

### Dynamic Team Management
- Teams with customizable field configurations stored as JSONB
- Support for various field types (text, select, number, date)
- Field validation and form generation
- Team-based data isolation

### Sales Management
- Create, update, and delete sales records
- Dynamic forms based on team configuration
- Status tracking and progress monitoring
- Team and user-based filtering

### Demo Management
- Schedule and track product demonstrations
- Status tracking (scheduled, completed, closed, lost)
- Team-specific demo filtering for Outbound Team
- Demo-to-deal conversion tracking
- Closed demo metrics in dashboard

### Renewal Tracking
- Renewal opportunity management with tabbed interface
- Status tracking (pending, completed, lost)
- Due date monitoring and alerts
- Annual renewal targets with done/target ratio calculations
- Renewal-specific performance analytics
- Team and individual renewal target setting
- Integration with sales pipeline

### Analytics and Reporting
- Team-specific performance analytics
- Field Sales Team: revenue, sales count, deals closed, average deal size metrics
- Outbound Team: demo count, demos closing as sold, demo close rate, revenue from demos
- Integrated top performers within each team section
- Export capabilities for reporting
- **Complete Goal Management System**:
  - Goal creation modal with team/member selection
  - Multiple goal types: Revenue, Sales Count, Demo Count, Conversion Rate
  - Period options: Monthly, Quarterly, Yearly
  - Progress tracking with visual progress bars
  - Edit and delete capabilities for existing goals
  - Turkish Lira formatting for revenue targets
  - Team-wide and individual goal assignment

### User Interface
- Horizontal tab-based navigation with 8 main sections
- Tab 1: Dashboard, Tab 2: Field Sales, Tab 3: Outbound, Tab 4: Renewals, Tab 5: Partnerships, Tab 6: Banks & PF's, Tab 7: Analytics, Tab 8: Settings
- Field Sales tab focuses on field team sales pipeline management
- Outbound tab focuses on outbound team demo scheduling and tracking
- Banks & PF's tab manages banking and private fund relationships
- Analytics tab provides comprehensive performance insights
- Settings tab includes Team Management and User Management subsections
- Clean page headers without duplicate text
- Responsive design with mobile support
- Modern component library (shadcn/ui)
- Dark/light theme support
- Consistent design system

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit Auth, sessions stored in PostgreSQL
2. **API Requests**: Frontend makes authenticated requests to Express API endpoints
3. **Database Operations**: Drizzle ORM handles all database interactions
4. **Real-time Updates**: React Query manages cache invalidation and data synchronization
5. **Form Handling**: Dynamic forms generated based on team configurations
6. **Role-based Access**: Middleware enforces permissions based on user roles

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless driver
- **drizzle-orm**: Type-safe ORM for database operations
- **@radix-ui/***: Unstyled, accessible UI primitives
- **@tanstack/react-query**: Server state management
- **react-hook-form**: Form handling and validation
- **zod**: Runtime type validation
- **recharts**: Data visualization library
- **lucide-react**: Icon library for UI components

### Authentication
- **openid-client**: OpenID Connect implementation
- **passport**: Authentication middleware
- **connect-pg-simple**: PostgreSQL session store

### Development Tools
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundling
- **tailwindcss**: Utility-first CSS framework

## Deployment Strategy

### Development Environment
- Vite development server with HMR
- Express server running in development mode
- Database migrations handled by Drizzle Kit
- Replit-specific development tools and error handling

### Production Build
- Vite builds the frontend to `dist/public`
- esbuild bundles the backend to `dist/index.js`
- Single deployment artifact with both frontend and backend
- Environment-based configuration

### Database Management
- Drizzle migrations in `migrations/` directory
- Schema definition in `shared/schema.ts`
- Push-based deployment with `db:push` command
- PostgreSQL connection via environment variable

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Session encryption key
- `REPLIT_DOMAINS`: Allowed domains for OIDC
- `ISSUER_URL`: OpenID Connect issuer URL
- `REPL_ID`: Replit application identifier

The application follows a monorepo structure with shared types and schemas, enabling type safety across the full stack while maintaining clear separation of concerns between client, server, and shared code.