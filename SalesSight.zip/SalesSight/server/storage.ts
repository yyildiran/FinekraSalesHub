import {
  users,
  teams,
  sales,
  renewals,
  demos,
  renewalTargets,
  partnerships,
  teamGoals,
  type User,
  type UpsertUser,
  type InsertUser,
  type Team,
  type InsertTeam,
  type Sale,
  type InsertSale,
  type Renewal,
  type InsertRenewal,
  type Demo,
  type InsertDemo,
  type RenewalTarget,
  type InsertRenewalTarget,
  type Partnership,
  type InsertPartnership,
  type TeamGoal,
  type InsertTeamGoal,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, count, sum, avg, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // User management
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User>;
  deleteUser(id: string): Promise<void>;
  getAllUsers(): Promise<User[]>;
  getUsersByTeam(teamId: number): Promise<User[]>;
  getUserByEmail(email: string): Promise<User | undefined>;
  
  // Team operations
  createTeam(team: InsertTeam): Promise<Team>;
  updateTeam(id: number, team: Partial<InsertTeam>): Promise<Team>;
  getTeam(id: number): Promise<Team | undefined>;
  getAllTeams(): Promise<Team[]>;
  
  // Sales operations
  createSale(sale: InsertSale): Promise<Sale>;
  updateSale(id: number, sale: Partial<InsertSale>): Promise<Sale>;
  deleteSale(id: number): Promise<void>;
  getSale(id: number): Promise<Sale | undefined>;
  getSalesByTeam(teamId: number): Promise<Sale[]>;
  getSalesByUser(userId: string): Promise<Sale[]>;
  getAllSales(): Promise<Sale[]>;
  
  // Renewal operations
  createRenewal(renewal: InsertRenewal): Promise<Renewal>;
  updateRenewal(id: number, renewal: Partial<InsertRenewal>): Promise<Renewal>;
  deleteRenewal(id: number): Promise<void>;
  getRenewal(id: number): Promise<Renewal | undefined>;
  getRenewalsByTeam(teamId: number): Promise<Renewal[]>;
  getRenewalsByUser(userId: string): Promise<Renewal[]>;
  getAllRenewals(): Promise<Renewal[]>;
  getUpcomingRenewals(days: number): Promise<Renewal[]>;
  
  // Demo operations
  createDemo(demo: InsertDemo): Promise<Demo>;
  updateDemo(id: number, demo: Partial<InsertDemo>): Promise<Demo>;
  deleteDemo(id: number): Promise<void>;
  getDemo(id: number): Promise<Demo | undefined>;
  getDemosByTeam(teamId: number): Promise<Demo[]>;
  getDemosByUser(userId: string): Promise<Demo[]>;
  getAllDemos(): Promise<Demo[]>;
  getClosedDemos(teamId?: number): Promise<Demo[]>;
  getDemoPerformance(startDate?: string, endDate?: string): Promise<any[]>;
  
  // Team goals operations
  createTeamGoal(goal: InsertTeamGoal): Promise<TeamGoal>;
  updateTeamGoal(id: number, goal: Partial<InsertTeamGoal>): Promise<TeamGoal>;
  deleteTeamGoal(id: number): Promise<void>;
  getTeamGoal(id: number): Promise<TeamGoal | undefined>;
  getTeamGoalsByTeam(teamId: number): Promise<TeamGoal[]>;
  getTeamGoalsByUser(userId: string): Promise<TeamGoal[]>;
  getAllTeamGoals(): Promise<TeamGoal[]>;
  
  // Partnership operations
  createPartnership(partnership: InsertPartnership): Promise<Partnership>;
  updatePartnership(id: number, partnership: Partial<InsertPartnership>): Promise<Partnership>;
  deletePartnership(id: number): Promise<void>;
  getAllPartnerships(): Promise<Partnership[]>;
  getPartnership(id: number): Promise<Partnership | undefined>;

  // Analytics
  getTeamPerformance(teamId?: number, startDate?: string, endDate?: string): Promise<any>;
  getSpecificTeamPerformance(teamId: number): Promise<any>;
  getKPIs(teamId?: number, userId?: string, startDate?: string, endDate?: string): Promise<any>;
  getRevenueData(months: number, teamId?: number, startDate?: string, endDate?: string): Promise<any>;
  getYearlyTargetAnalytics(year: number, teamId?: number, salesRepId?: string): Promise<any>;
  getTopPerformers(teamId?: number): Promise<any>;
  getSalesFunnelData(teamId?: number): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // User management
  async createUser(userData: InsertUser): Promise<User> {
    // Generate a unique ID if not provided
    const userDataWithId = {
      ...userData,
      id: userData.id || `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
    const [user] = await db.insert(users).values(userDataWithId).returning();
    return user;
  }

  async updateUser(id: string, userData: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...userData, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async deleteUser(id: string): Promise<void> {
    await db.update(users).set({ isActive: false }).where(eq(users.id, id));
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.isActive, true)).orderBy(desc(users.createdAt));
  }

  async getUsersByTeam(teamId: number): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(and(eq(users.teamId, teamId), eq(users.isActive, true)))
      .orderBy(desc(users.createdAt));
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(and(eq(users.email, email), eq(users.isActive, true)));
    return user;
  }

  // Team operations
  async createTeam(teamData: InsertTeam): Promise<Team> {
    const [team] = await db.insert(teams).values(teamData).returning();
    return team;
  }

  async updateTeam(id: number, teamData: Partial<InsertTeam>): Promise<Team> {
    const [team] = await db
      .update(teams)
      .set({ ...teamData, updatedAt: new Date() })
      .where(eq(teams.id, id))
      .returning();
    return team;
  }

  async getTeam(id: number): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team;
  }

  async getAllTeams(): Promise<Team[]> {
    return await db.select().from(teams).orderBy(desc(teams.createdAt));
  }

  // Sales operations
  async createSale(saleData: InsertSale): Promise<Sale> {
    const [sale] = await db.insert(sales).values(saleData).returning();
    return sale;
  }

  async updateSale(id: number, saleData: Partial<InsertSale>): Promise<Sale> {
    const [sale] = await db
      .update(sales)
      .set({ ...saleData, updatedAt: new Date() })
      .where(eq(sales.id, id))
      .returning();
    return sale;
  }

  async deleteSale(id: number): Promise<void> {
    await db.delete(sales).where(eq(sales.id, id));
  }

  async getSale(id: number): Promise<Sale | undefined> {
    const [sale] = await db.select().from(sales).where(eq(sales.id, id));
    return sale;
  }

  async getSalesByTeam(teamId: number): Promise<Sale[]> {
    return await db
      .select()
      .from(sales)
      .where(eq(sales.teamId, teamId))
      .orderBy(desc(sales.createdAt));
  }

  async getSalesByUser(userId: string): Promise<Sale[]> {
    return await db
      .select()
      .from(sales)
      .where(eq(sales.salesRepId, userId))
      .orderBy(desc(sales.createdAt));
  }

  async getAllSales(): Promise<Sale[]> {
    return await db.select().from(sales).orderBy(desc(sales.createdAt));
  }

  // Renewal operations
  async createRenewal(renewalData: InsertRenewal): Promise<Renewal> {
    const [renewal] = await db.insert(renewals).values(renewalData).returning();
    return renewal;
  }

  async updateRenewal(id: number, renewalData: Partial<InsertRenewal>): Promise<Renewal> {
    const [renewal] = await db
      .update(renewals)
      .set({ ...renewalData, updatedAt: new Date() })
      .where(eq(renewals.id, id))
      .returning();
    return renewal;
  }

  async deleteRenewal(id: number): Promise<void> {
    await db.delete(renewals).where(eq(renewals.id, id));
  }

  async getRenewal(id: number): Promise<Renewal | undefined> {
    const [renewal] = await db.select().from(renewals).where(eq(renewals.id, id));
    return renewal;
  }

  async getRenewalsByTeam(teamId: number): Promise<Renewal[]> {
    return await db
      .select()
      .from(renewals)
      .where(eq(renewals.teamId, teamId))
      .orderBy(desc(renewals.createdAt));
  }

  async getRenewalsByUser(userId: string): Promise<Renewal[]> {
    return await db
      .select()
      .from(renewals)
      .where(eq(renewals.salesRepId, userId))
      .orderBy(desc(renewals.createdAt));
  }

  async getAllRenewals(): Promise<any[]> {
    return await db
      .select({
        id: renewals.id,
        saleId: renewals.saleId,
        clientName: renewals.clientName,
        originalAmount: renewals.originalAmount,
        renewalAmount: renewals.renewalAmount,
        originalCloseDate: renewals.originalCloseDate,
        renewalDate: renewals.renewalDate,
        expiryDate: renewals.expiryDate,
        status: renewals.status,
        salesRepId: renewals.salesRepId,
        teamId: renewals.teamId,
        notes: renewals.notes,
        createdAt: renewals.createdAt,
        updatedAt: renewals.updatedAt,
        sale: {
          id: sales.id,
          amount: sales.amount,
          closeDate: sales.closeDate,
        }
      })
      .from(renewals)
      .leftJoin(sales, eq(renewals.saleId, sales.id))
      .orderBy(desc(renewals.createdAt));
  }

  async getUpcomingRenewals(days: number): Promise<any[]> {
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + days);

    return await db
      .select({
        id: renewals.id,
        saleId: renewals.saleId,
        clientName: renewals.clientName,
        originalAmount: renewals.originalAmount,
        renewalAmount: renewals.renewalAmount,
        originalCloseDate: renewals.originalCloseDate,
        renewalDate: renewals.renewalDate,
        expiryDate: renewals.expiryDate,
        status: renewals.status,
        salesRepId: renewals.salesRepId,
        teamId: renewals.teamId,
        notes: renewals.notes,
        createdAt: renewals.createdAt,
        updatedAt: renewals.updatedAt,
        sale: {
          id: sales.id,
          amount: sales.amount,
          closeDate: sales.closeDate,
        }
      })
      .from(renewals)
      .leftJoin(sales, eq(renewals.saleId, sales.id))
      .where(
        and(
          eq(renewals.status, "pending"),
          gte(renewals.expiryDate, today.toISOString().split('T')[0]),
          lte(renewals.expiryDate, futureDate.toISOString().split('T')[0])
        )
      )
      .orderBy(renewals.expiryDate);
  }

  // Demo operations
  async createDemo(demoData: InsertDemo): Promise<Demo> {
    const [demo] = await db.insert(demos).values(demoData).returning();
    return demo;
  }

  async updateDemo(id: number, demoData: Partial<InsertDemo>): Promise<Demo> {
    const [demo] = await db
      .update(demos)
      .set({ ...demoData, updatedAt: new Date() })
      .where(eq(demos.id, id))
      .returning();
    return demo;
  }

  async deleteDemo(id: number): Promise<void> {
    await db.delete(demos).where(eq(demos.id, id));
  }

  async getDemo(id: number): Promise<Demo | undefined> {
    const [demo] = await db.select().from(demos).where(eq(demos.id, id));
    return demo;
  }

  async getDemosByTeam(teamId: number): Promise<Demo[]> {
    return await db
      .select()
      .from(demos)
      .where(eq(demos.teamId, teamId))
      .orderBy(desc(demos.createdAt));
  }

  async getDemosByUser(userId: string): Promise<Demo[]> {
    return await db
      .select()
      .from(demos)
      .where(eq(demos.salesRepId, userId))
      .orderBy(desc(demos.createdAt));
  }

  async getAllDemos(): Promise<Demo[]> {
    return await db.select().from(demos).orderBy(desc(demos.createdAt));
  }

  async getClosedDemos(teamId?: number): Promise<Demo[]> {
    const conditions = [eq(demos.status, "closed")];
    if (teamId) {
      conditions.push(eq(demos.teamId, teamId));
    }
    
    return await db
      .select()
      .from(demos)
      .where(and(...conditions))
      .orderBy(desc(demos.createdAt));
  }

  async getDemoPerformance(startDate?: string, endDate?: string): Promise<any[]> {
    let query = db
      .select({
        salesRepId: demos.salesRepId,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        totalDemos: sql<number>`count(*)::int`,
        scheduledDemos: sql<number>`count(case when ${demos.status} = 'scheduled' then 1 end)::int`,
        completedDemos: sql<number>`count(case when ${demos.status} = 'completed' then 1 end)::int`,
        closedDemos: sql<number>`count(case when ${demos.status} = 'closed' then 1 end)::int`,
        lostDemos: sql<number>`count(case when ${demos.status} = 'lost' then 1 end)::int`,
      })
      .from(demos)
      .leftJoin(users, eq(demos.salesRepId, users.id));

    // Apply date range filter if provided
    if (startDate && endDate) {
      query = query.where(
        and(
          gte(demos.demoDate, startDate),
          lte(demos.demoDate, endDate)
        )
      );
    }

    const result = await query
      .groupBy(demos.salesRepId, users.firstName, users.lastName, users.email)
      .orderBy(sql`count(*)::int desc`);

    return result;
  }

  // Renewal targets operations
  async createRenewalTarget(target: InsertRenewalTarget): Promise<RenewalTarget> {
    const [created] = await db.insert(renewalTargets).values(target).returning();
    return created;
  }

  async updateRenewalTarget(id: number, target: Partial<InsertRenewalTarget>): Promise<RenewalTarget> {
    const [updated] = await db
      .update(renewalTargets)
      .set(target)
      .where(eq(renewalTargets.id, id))
      .returning();
    return updated;
  }

  async deleteRenewalTarget(id: number): Promise<void> {
    await db.delete(renewalTargets).where(eq(renewalTargets.id, id));
  }

  async getRenewalTarget(id: number): Promise<RenewalTarget | undefined> {
    const [target] = await db
      .select()
      .from(renewalTargets)
      .where(eq(renewalTargets.id, id));
    return target;
  }

  async getRenewalTargetsByYear(year: number, teamId?: number, salesRepId?: string): Promise<RenewalTarget[]> {
    const conditions = [eq(renewalTargets.year, year)];
    
    if (teamId) {
      conditions.push(eq(renewalTargets.teamId, teamId));
    }
    
    if (salesRepId) {
      conditions.push(eq(renewalTargets.salesRepId, salesRepId));
    }
    
    return await db
      .select()
      .from(renewalTargets)
      .where(and(...conditions))
      .orderBy(desc(renewalTargets.createdAt));
  }

  async getAllRenewalTargets(): Promise<RenewalTarget[]> {
    return await db
      .select()
      .from(renewalTargets)
      .orderBy(desc(renewalTargets.year), desc(renewalTargets.createdAt));
  }

  async getRenewalTargetAnalytics(year: number, teamId?: number, salesRepId?: string): Promise<any> {
    // Get targets for the year
    const targets = await this.getRenewalTargetsByYear(year, teamId, salesRepId);
    
    // Get actual renewal performance for the year
    const startDate = `${year}-01-01`;
    const endDate = `${year}-12-31`;
    
    const renewalConditions = [
      gte(renewals.expiryDate, startDate),
      lte(renewals.expiryDate, endDate)
    ];
    
    if (teamId) {
      renewalConditions.push(eq(renewals.teamId, teamId));
    }
    
    if (salesRepId) {
      renewalConditions.push(eq(renewals.salesRepId, salesRepId));
    }
    
    // Get actual renewal performance
    const actualRenewals = await db
      .select()
      .from(renewals)
      .where(and(...renewalConditions));
    
    const completedRenewals = actualRenewals.filter(renewal => renewal.status === "completed");
    const actualRenewalRevenue = completedRenewals.reduce((sum, renewal) => sum + parseFloat(renewal.amount), 0);
    const actualRenewalCount = completedRenewals.length;
    const totalRenewalsProcessed = actualRenewals.length;
    
    // Calculate ratios for each target
    const targetAnalytics = targets.map(target => {
      const revenueRatio = target.renewalRevenueTarget ? 
        (actualRenewalRevenue / parseFloat(target.renewalRevenueTarget)) * 100 : null;
      const countRatio = target.renewalCountTarget ? 
        (actualRenewalCount / target.renewalCountTarget) * 100 : null;
      
      return {
        ...target,
        actualRenewalRevenue,
        actualRenewalCount,
        totalRenewalsProcessed,
        revenueRatio,
        countRatio,
      };
    });
    
    return {
      targets: targetAnalytics,
      summary: {
        actualRenewalRevenue,
        actualRenewalCount,
        totalRenewalsProcessed,
      }
    };
  }

  // Analytics
  async getTeamPerformance(teamId?: number, startDate?: string, endDate?: string): Promise<any> {
    const conditions = [eq(sales.status, "closed")];
    
    if (teamId) {
      conditions.push(eq(sales.teamId, teamId));
    }

    if (startDate && endDate) {
      conditions.push(gte(sales.closeDate, startDate));
      conditions.push(lte(sales.closeDate, endDate));
    }

    const query = db
      .select({
        teamId: sales.teamId,
        salesRepId: sales.salesRepId,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        totalSales: count(sales.id),
        totalRevenue: sum(sales.amount),
      })
      .from(sales)
      .leftJoin(users, eq(sales.salesRepId, users.id))
      .where(and(...conditions))
      .groupBy(sales.teamId, sales.salesRepId, users.firstName, users.lastName, users.email);

    return await query;
  }

  async getKPIs(teamId?: number, userId?: string, startDate?: string, endDate?: string): Promise<any> {
    let salesQuery = db.select().from(sales);
    let renewalsQuery = db.select().from(renewals);

    const salesConditions = [];
    const renewalsConditions = [];

    if (teamId) {
      salesConditions.push(eq(sales.teamId, teamId));
      renewalsConditions.push(eq(renewals.teamId, teamId));
    }

    if (userId) {
      salesConditions.push(eq(sales.salesRepId, userId));
      renewalsConditions.push(eq(renewals.salesRepId, userId));
    }

    if (startDate && endDate) {
      salesConditions.push(gte(sales.closeDate, startDate));
      salesConditions.push(lte(sales.closeDate, endDate));
      renewalsConditions.push(gte(renewals.expiryDate, startDate));
      renewalsConditions.push(lte(renewals.expiryDate, endDate));
    }

    if (salesConditions.length > 0) {
      salesQuery = salesQuery.where(and(...salesConditions));
    }
    if (renewalsConditions.length > 0) {
      renewalsQuery = renewalsQuery.where(and(...renewalsConditions));
    }

    const allSales = await salesQuery;
    const allRenewals = await renewalsQuery;

    // Calculate revenue breakdown
    const newSalesRevenue = allSales
      .filter(sale => sale.status === "closed")
      .reduce((sum, sale) => sum + parseFloat(sale.amount), 0);
    
    const renewalsRevenue = allRenewals
      .filter(renewal => renewal.status === "completed")
      .reduce((sum, renewal) => sum + parseFloat(renewal.renewalAmount), 0);
    
    // Banks & PFs revenue placeholder - would connect to actual data later
    const banksPFsRevenue = 0;
    
    const totalRevenue = newSalesRevenue + renewalsRevenue + banksPFsRevenue;

    const dealsClosed = allSales.filter(sale => sale.status === "closed").length;
    const totalDeals = allSales.length;
    const conversionRate = totalDeals > 0 ? (dealsClosed / totalDeals) * 100 : 0;
    const activeRenewals = allRenewals.filter(renewal => renewal.status === "pending").length;

    const avgDealSize = dealsClosed > 0 ? newSalesRevenue / dealsClosed : 0;

    return {
      totalRevenue,
      newSalesRevenue,
      renewalsRevenue,
      banksPFsRevenue,
      dealsClosed,
      conversionRate,
      avgDealSize,
      activeRenewals,
    };
  }

  async getRevenueData(months: number, teamId?: number, startDate?: string, endDate?: string): Promise<any> {
    let filterStartDate = startDate;
    let filterEndDate = endDate;

    // If no custom date range, use months parameter
    if (!startDate || !endDate) {
      const defaultStartDate = new Date();
      defaultStartDate.setMonth(defaultStartDate.getMonth() - months);
      filterStartDate = defaultStartDate.toISOString().split('T')[0];
      filterEndDate = new Date().toISOString().split('T')[0];
    }

    let baseQuery = db
      .select({
        month: sales.closeDate,
        revenue: sum(sales.amount),
      })
      .from(sales)
      .groupBy(sales.closeDate);

    const conditions = [
      eq(sales.status, "closed"),
      gte(sales.closeDate, filterStartDate!),
      lte(sales.closeDate, filterEndDate!)
    ];

    if (teamId) {
      conditions.push(eq(sales.teamId, teamId));
    }

    return await baseQuery.where(and(...conditions));
  }

  // Demo operations
  async createDemo(demoData: InsertDemo): Promise<Demo> {
    const [demo] = await db.insert(demos).values(demoData).returning();
    return demo;
  }

  async updateDemo(id: number, demoData: Partial<InsertDemo>): Promise<Demo> {
    const [demo] = await db
      .update(demos)
      .set({ ...demoData, updatedAt: new Date() })
      .where(eq(demos.id, id))
      .returning();
    return demo;
  }

  async deleteDemo(id: number): Promise<void> {
    await db.delete(demos).where(eq(demos.id, id));
  }

  async getDemo(id: number): Promise<Demo | undefined> {
    const [demo] = await db.select().from(demos).where(eq(demos.id, id));
    return demo;
  }

  async getDemosByTeam(teamId: number): Promise<Demo[]> {
    return await db
      .select()
      .from(demos)
      .where(eq(demos.teamId, teamId))
      .orderBy(desc(demos.createdAt));
  }

  async getDemosByUser(userId: string): Promise<Demo[]> {
    return await db
      .select()
      .from(demos)
      .where(eq(demos.salesRepId, userId))
      .orderBy(desc(demos.createdAt));
  }

  async getAllDemos(): Promise<Demo[]> {
    return await db.select().from(demos).orderBy(desc(demos.createdAt));
  }

  async getClosedDemos(teamId?: number): Promise<Demo[]> {
    if (teamId) {
      return await db
        .select()
        .from(demos)
        .where(and(eq(demos.status, "closed"), eq(demos.teamId, teamId)))
        .orderBy(desc(demos.createdAt));
    } else {
      return await db
        .select()
        .from(demos)
        .where(eq(demos.status, "closed"))
        .orderBy(desc(demos.createdAt));
    }
  }

  async getTopPerformers(teamId?: number): Promise<any> {
    let performers;
    
    if (teamId) {
      performers = await db
        .select({
          salesRepId: sales.salesRepId,
          totalRevenue: sum(sales.amount),
          totalSales: count(sales.id),
        })
        .from(sales)
        .innerJoin(users, eq(sales.salesRepId, users.id))
        .where(and(eq(sales.status, "closed"), eq(sales.teamId, teamId)))
        .groupBy(sales.salesRepId)
        .orderBy(desc(sum(sales.amount)))
        .limit(10);
    } else {
      performers = await db
        .select({
          salesRepId: sales.salesRepId,
          totalRevenue: sum(sales.amount),
          totalSales: count(sales.id),
        })
        .from(sales)
        .innerJoin(users, eq(sales.salesRepId, users.id))
        .where(eq(sales.status, "closed"))
        .groupBy(sales.salesRepId)
        .orderBy(desc(sum(sales.amount)))
        .limit(10);
    }
    
    // Get user details for each performer
    const performersWithDetails = await Promise.all(
      performers.map(async (performer) => {
        const user = await this.getUser(performer.salesRepId);
        return {
          salesRepId: performer.salesRepId,
          firstName: user?.firstName,
          lastName: user?.lastName,
          email: user?.email,
          totalRevenue: parseFloat(String(performer.totalRevenue || 0)),
          totalSales: parseInt(String(performer.totalSales || 0)),
        };
      })
    );

    return performersWithDetails;
  }

  async getTopDemoTakers(teamId?: number): Promise<any> {
    let performers;
    
    if (teamId) {
      performers = await db
        .select({
          salesRepId: demos.salesRepId,
          totalDemos: count(demos.id),
        })
        .from(demos)
        .innerJoin(users, eq(demos.salesRepId, users.id))
        .where(eq(demos.teamId, teamId))
        .groupBy(demos.salesRepId)
        .orderBy(desc(count(demos.id)))
        .limit(10);
    } else {
      performers = await db
        .select({
          salesRepId: demos.salesRepId,
          totalDemos: count(demos.id),
        })
        .from(demos)
        .innerJoin(users, eq(demos.salesRepId, users.id))
        .groupBy(demos.salesRepId)
        .orderBy(desc(count(demos.id)))
        .limit(10);
    }
    
    // Get user details for each performer
    const performersWithDetails = await Promise.all(
      performers.map(async (performer) => {
        const user = await this.getUser(performer.salesRepId);
        return {
          salesRepId: performer.salesRepId,
          firstName: user?.firstName,
          lastName: user?.lastName,
          email: user?.email,
          totalDemos: parseInt(String(performer.totalDemos || 0)),
        };
      })
    );

    return performersWithDetails;
  }



  async getSpecificTeamPerformance(teamId: number): Promise<any> {
    // Get team info
    const team = await this.getTeam(teamId);
    if (!team) {
      return null;
    }

    // Get sales performance for the team
    const salesData = await db
      .select({
        totalRevenue: sum(sales.amount),
        dealsClosed: count(sales.id),
      })
      .from(sales)
      .where(and(eq(sales.teamId, teamId), eq(sales.status, "closed")));

    // Get demo performance for the team (especially important for Outbound Team)
    const demoData = await db
      .select({
        totalDemos: count(demos.id),
      })
      .from(demos)
      .where(eq(demos.teamId, teamId));

    const closedDemoData = await db
      .select({
        closedDemos: count(demos.id),
      })
      .from(demos)
      .where(and(eq(demos.teamId, teamId), eq(demos.status, "closed")));

    const salesResult = salesData[0] || { totalRevenue: "0", dealsClosed: "0" };
    const demoResult = demoData[0] || { totalDemos: "0" };
    const closedDemoResult = closedDemoData[0] || { closedDemos: "0" };

    return {
      teamId,
      teamName: team.name,
      totalRevenue: parseFloat(String(salesResult.totalRevenue || 0)),
      dealsClosed: parseInt(String(salesResult.dealsClosed || 0)),
      demoCount: parseInt(String(demoResult.totalDemos || 0)),
      closedDemos: parseInt(String(closedDemoResult.closedDemos || 0)),
    };
  }

  async getSalesFunnelData(teamId?: number): Promise<any> {
    let salesQuery = db
      .select({
        status: sales.status,
        count: count(sales.id),
        totalAmount: sum(sales.amount)
      })
      .from(sales)
      .groupBy(sales.status);

    if (teamId) {
      salesQuery = salesQuery.where(eq(sales.teamId, teamId));
    }

    const salesData = await salesQuery;

    return {
      funnel: salesData.map(item => ({
        status: item.status,
        count: parseInt(String(item.count || 0)),
        totalAmount: parseFloat(String(item.totalAmount || 0))
      }))
    };
  }

  // Partnership operations
  async createPartnership(partnershipData: InsertPartnership): Promise<Partnership> {
    const [partnership] = await db.insert(partnerships).values(partnershipData).returning();
    return partnership;
  }

  async updatePartnership(id: number, partnershipData: Partial<InsertPartnership>): Promise<Partnership> {
    const [partnership] = await db
      .update(partnerships)
      .set({ ...partnershipData, updatedAt: new Date() })
      .where(eq(partnerships.id, id))
      .returning();
    return partnership;
  }

  async deletePartnership(id: number): Promise<void> {
    await db.delete(partnerships).where(eq(partnerships.id, id));
  }

  async getAllPartnerships(): Promise<Partnership[]> {
    return await db.select().from(partnerships).orderBy(desc(partnerships.createdAt));
  }

  async getPartnership(id: number): Promise<Partnership | undefined> {
    const [partnership] = await db.select().from(partnerships).where(eq(partnerships.id, id));
    return partnership;
  }
  // Team Goal operations
  async createTeamGoal(goalData: InsertTeamGoal): Promise<TeamGoal> {
    const [goal] = await db.insert(teamGoals).values(goalData).returning();
    return goal;
  }

  async updateTeamGoal(id: number, goalData: Partial<InsertTeamGoal>): Promise<TeamGoal> {
    const [goal] = await db
      .update(teamGoals)
      .set({ ...goalData, updatedAt: new Date() })
      .where(eq(teamGoals.id, id))
      .returning();
    return goal;
  }

  async deleteTeamGoal(id: number): Promise<void> {
    await db.delete(teamGoals).where(eq(teamGoals.id, id));
  }

  async getTeamGoal(id: number): Promise<TeamGoal | undefined> {
    const [goal] = await db.select().from(teamGoals).where(eq(teamGoals.id, id));
    return goal;
  }

  async getAllTeamGoals(): Promise<TeamGoal[]> {
    return await db.select().from(teamGoals).orderBy(desc(teamGoals.createdAt));
  }

  async getTeamGoalsByTeam(teamId: number): Promise<TeamGoal[]> {
    return await db.select().from(teamGoals).where(eq(teamGoals.teamId, teamId));
  }

  async getTeamGoalsByUser(userId: string): Promise<TeamGoal[]> {
    return await db.select().from(teamGoals).where(eq(teamGoals.salesRepId, userId));
  }
}

export const storage = new DatabaseStorage();
