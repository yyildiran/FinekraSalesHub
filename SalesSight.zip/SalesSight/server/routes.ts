import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertUserSchema, insertTeamSchema, insertSaleSchema, insertRenewalSchema, insertDemoSchema, insertPartnershipSchema } from "@shared/schema";
import { z } from "zod";


export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User management routes
  app.get('/api/users', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser || !['admin', 'manager'].includes(currentUser.role)) {
        return res.status(403).json({ message: "Insufficient permissions" });
      }

      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post('/api/users', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.put('/api/users/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const userId = req.params.id;
      const userData = insertUserSchema.partial().parse(req.body);
      const user = await storage.updateUser(userId, userData);
      res.json(user);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.delete('/api/users/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const userId = req.params.id;
      await storage.deleteUser(userId);
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Team management routes
  app.get('/api/teams', isAuthenticated, async (req: any, res) => {
    try {
      const teams = await storage.getAllTeams();
      res.json(teams);
    } catch (error) {
      console.error("Error fetching teams:", error);
      res.status(500).json({ message: "Failed to fetch teams" });
    }
  });

  app.post('/api/teams', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser || !['admin', 'manager'].includes(currentUser.role)) {
        return res.status(403).json({ message: "Manager or admin access required" });
      }

      const teamData = insertTeamSchema.parse(req.body);
      const team = await storage.createTeam(teamData);
      res.json(team);
    } catch (error) {
      console.error("Error creating team:", error);
      res.status(500).json({ message: "Failed to create team" });
    }
  });

  app.put('/api/teams/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser || !['admin', 'manager'].includes(currentUser.role)) {
        return res.status(403).json({ message: "Manager or admin access required" });
      }

      const teamId = parseInt(req.params.id);
      const teamData = insertTeamSchema.partial().parse(req.body);
      const team = await storage.updateTeam(teamId, teamData);
      res.json(team);
    } catch (error) {
      console.error("Error updating team:", error);
      res.status(500).json({ message: "Failed to update team" });
    }
  });

  app.get('/api/teams/:id', isAuthenticated, async (req: any, res) => {
    try {
      const teamId = parseInt(req.params.id);
      const team = await storage.getTeam(teamId);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      res.json(team);
    } catch (error) {
      console.error("Error fetching team:", error);
      res.status(500).json({ message: "Failed to fetch team" });
    }
  });

  // Sales routes
  app.get('/api/sales', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      let sales;
      if (currentUser.role === 'admin') {
        sales = await storage.getAllSales();
      } else if (currentUser.role === 'manager' && currentUser.teamId) {
        sales = await storage.getSalesByTeam(currentUser.teamId);
      } else {
        sales = await storage.getSalesByUser(currentUser.id);
      }

      res.json(sales);
    } catch (error) {
      console.error("Error fetching sales:", error);
      res.status(500).json({ message: "Failed to fetch sales" });
    }
  });

  app.post('/api/sales', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const saleData = insertSaleSchema.parse(req.body);
      
      // Create the sale
      const sale = await storage.createSale(saleData);

      // Automatically create renewal record
      const renewalData = {
        saleId: sale.id,
        clientName: sale.clientName,
        originalAmount: sale.amount,
        originalCloseDate: sale.closeDate,
        expiryDate: new Date(new Date(sale.closeDate).getTime() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 1 year from close date
        salesRepId: sale.salesRepId,
        teamId: sale.teamId,
        status: "pending" as const,
      };

      await storage.createRenewal(renewalData);

      res.json(sale);
    } catch (error) {
      console.error("Error creating sale:", error);
      res.status(500).json({ message: "Failed to create sale" });
    }
  });

  app.put('/api/sales/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const saleId = parseInt(req.params.id);
      const saleData = insertSaleSchema.partial().parse(req.body);
      
      // Check permissions
      const existingSale = await storage.getSale(saleId);
      if (!existingSale) {
        return res.status(404).json({ message: "Sale not found" });
      }

      if (currentUser.role === 'sales_rep' && existingSale.salesRepId !== currentUser.id) {
        return res.status(403).json({ message: "Can only edit your own sales" });
      }

      const sale = await storage.updateSale(saleId, saleData);
      res.json(sale);
    } catch (error) {
      console.error("Error updating sale:", error);
      res.status(500).json({ message: "Failed to update sale" });
    }
  });

  // Renewals routes
  app.get('/api/renewals', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      let renewals;
      if (currentUser.role === 'admin') {
        renewals = await storage.getAllRenewals();
      } else if (currentUser.role === 'manager' && currentUser.teamId) {
        renewals = await storage.getRenewalsByTeam(currentUser.teamId);
      } else {
        renewals = await storage.getRenewalsByUser(currentUser.id);
      }

      res.json(renewals);
    } catch (error) {
      console.error("Error fetching renewals:", error);
      res.status(500).json({ message: "Failed to fetch renewals" });
    }
  });

  app.get('/api/renewals/upcoming', isAuthenticated, async (req: any, res) => {
    try {
      const days = parseInt(req.query.days as string) || 30;
      const renewals = await storage.getUpcomingRenewals(days);
      res.json(renewals);
    } catch (error) {
      console.error("Error fetching upcoming renewals:", error);
      res.status(500).json({ message: "Failed to fetch upcoming renewals" });
    }
  });

  app.put('/api/renewals/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const renewalId = parseInt(req.params.id);
      const renewalData = insertRenewalSchema.partial().parse(req.body);
      
      // Check permissions
      const existingRenewal = await storage.getRenewal(renewalId);
      if (!existingRenewal) {
        return res.status(404).json({ message: "Renewal not found" });
      }

      if (currentUser.role === 'sales_rep' && existingRenewal.salesRepId !== currentUser.id) {
        return res.status(403).json({ message: "Can only edit your own renewals" });
      }

      const renewal = await storage.updateRenewal(renewalId, renewalData);
      res.json(renewal);
    } catch (error) {
      console.error("Error updating renewal:", error);
      res.status(500).json({ message: "Failed to update renewal" });
    }
  });

  // Analytics routes
  app.get('/api/analytics/kpis', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      let teamId = undefined;
      let userId = undefined;

      if (currentUser.role === 'sales_rep') {
        userId = currentUser.id;
      } else if (currentUser.role === 'manager' && currentUser.teamId) {
        teamId = currentUser.teamId;
      }

      const startDate = req.query.startDate as string;
      const endDate = req.query.endDate as string;

      const kpis = await storage.getKPIs(teamId, userId, startDate, endDate);
      res.json(kpis);
    } catch (error) {
      console.error("Error fetching KPIs:", error);
      res.status(500).json({ message: "Failed to fetch KPIs" });
    }
  });

  app.get('/api/analytics/revenue', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const months = parseInt(req.query.months as string) || 6;
      const startDate = req.query.startDate as string;
      const endDate = req.query.endDate as string;
      let teamId = undefined;

      if (currentUser.role === 'manager' && currentUser.teamId) {
        teamId = currentUser.teamId;
      }

      const revenueData = await storage.getRevenueData(months, teamId, startDate, endDate);
      res.json(revenueData);
    } catch (error) {
      console.error("Error fetching revenue data:", error);
      res.status(500).json({ message: "Failed to fetch revenue data" });
    }
  });

  app.get('/api/analytics/team-performance', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      let teamId = undefined;
      if (currentUser.role === 'manager' && currentUser.teamId) {
        teamId = currentUser.teamId;
      }

      const startDate = req.query.startDate as string;
      const endDate = req.query.endDate as string;

      const performance = await storage.getTeamPerformance(teamId, startDate, endDate);
      res.json(performance);
    } catch (error) {
      console.error("Error fetching team performance:", error);
      res.status(500).json({ message: "Failed to fetch team performance" });
    }
  });

  // Team-specific performance endpoint
  app.get('/api/analytics/team-performance/:teamId', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const teamId = parseInt(req.params.teamId);
      const performance = await storage.getSpecificTeamPerformance(teamId);
      res.json(performance);
    } catch (error) {
      console.error("Error fetching specific team performance:", error);
      res.status(500).json({ message: "Failed to fetch team performance" });
    }
  });

  // Top performers endpoint
  app.get('/api/analytics/top-performers', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      let teamId = undefined;
      if (currentUser.role === 'manager' && currentUser.teamId) {
        teamId = currentUser.teamId;
      }

      const topPerformers = await storage.getTopPerformers(teamId);
      res.json(topPerformers);
    } catch (error) {
      console.error("Error fetching top performers:", error);
      res.status(500).json({ message: "Failed to fetch top performers" });
    }
  });

  // Team-specific top performers endpoint
  app.get('/api/analytics/top-performers/:teamId', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const teamId = parseInt(req.params.teamId);
      const topPerformers = await storage.getTopPerformers(teamId);
      res.json(topPerformers);
    } catch (error) {
      console.error("Error fetching team-specific top performers:", error);
      res.status(500).json({ message: "Failed to fetch team-specific top performers" });
    }
  });

  // Team-specific top demo takers endpoint
  app.get('/api/analytics/top-demo-takers/:teamId', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const teamId = parseInt(req.params.teamId);
      const topDemoTakers = await storage.getTopDemoTakers(teamId);
      res.json(topDemoTakers);
    } catch (error) {
      console.error("Error fetching team-specific top demo takers:", error);
      res.status(500).json({ message: "Failed to fetch team-specific top demo takers" });
    }
  });



  // Demo routes
  app.get('/api/demos', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      let demos;
      if (currentUser.role === 'sales_rep') {
        demos = await storage.getDemosByUser(currentUser.id);
      } else if (currentUser.role === 'manager' && currentUser.teamId) {
        demos = await storage.getDemosByTeam(currentUser.teamId);
      } else {
        demos = await storage.getAllDemos();
      }

      res.json(demos);
    } catch (error) {
      console.error("Error fetching demos:", error);
      res.status(500).json({ message: "Failed to fetch demos" });
    }
  });

  app.post('/api/demos', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      console.log("Request body:", req.body);
      const demoData = insertDemoSchema.parse(req.body);
      console.log("Parsed demo data:", demoData);
      
      // Check permissions
      if (currentUser.role === 'sales_rep' && demoData.salesRepId !== currentUser.id) {
        return res.status(403).json({ message: "Can only create demos for yourself" });
      }

      const demo = await storage.createDemo(demoData);
      console.log("Created demo:", demo);
      res.json(demo);
    } catch (error) {
      console.error("Error creating demo:", error);
      if (error instanceof Error) {
        console.error("Error details:", error.message);
      }
      res.status(500).json({ message: "Failed to create demo", error: error instanceof Error ? error.message : String(error) });
    }
  });

  app.put('/api/demos/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const demoId = parseInt(req.params.id);
      const demoData = insertDemoSchema.partial().parse(req.body);
      
      // Check permissions
      const existingDemo = await storage.getDemo(demoId);
      if (!existingDemo) {
        return res.status(404).json({ message: "Demo not found" });
      }

      if (currentUser.role === 'sales_rep' && existingDemo.salesRepId !== currentUser.id) {
        return res.status(403).json({ message: "Can only edit your own demos" });
      }

      const demo = await storage.updateDemo(demoId, demoData);
      res.json(demo);
    } catch (error) {
      console.error("Error updating demo:", error);
      res.status(500).json({ message: "Failed to update demo" });
    }
  });

  app.delete('/api/demos/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const demoId = parseInt(req.params.id);
      
      // Check permissions
      const existingDemo = await storage.getDemo(demoId);
      if (!existingDemo) {
        return res.status(404).json({ message: "Demo not found" });
      }

      if (currentUser.role === 'sales_rep' && existingDemo.salesRepId !== currentUser.id) {
        return res.status(403).json({ message: "Can only delete your own demos" });
      }

      await storage.deleteDemo(demoId);
      res.json({ message: "Demo deleted successfully" });
    } catch (error) {
      console.error("Error deleting demo:", error);
      res.status(500).json({ message: "Failed to delete demo" });
    }
  });

  app.get('/api/demos/closed', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      let teamId = undefined;
      if (currentUser.role === 'manager' && currentUser.teamId) {
        teamId = currentUser.teamId;
      }

      const closedDemos = await storage.getClosedDemos(teamId);
      res.json(closedDemos);
    } catch (error) {
      console.error("Error fetching closed demos:", error);
      res.status(500).json({ message: "Failed to fetch closed demos" });
    }
  });

  app.get('/api/demos/performance', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const { startDate, endDate } = req.query;
      const demoPerformance = await storage.getDemoPerformance(startDate as string, endDate as string);
      res.json(demoPerformance);
    } catch (error) {
      console.error("Error fetching demo performance:", error);
      res.status(500).json({ message: "Failed to fetch demo performance" });
    }
  });

  // Renewal targets routes
  app.get('/api/renewal-targets', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const { year, teamId, salesRepId } = req.query;
      
      if (year) {
        const targets = await storage.getRenewalTargetsByYear(
          parseInt(year as string),
          teamId ? parseInt(teamId as string) : undefined,
          salesRepId as string
        );
        res.json(targets);
      } else {
        const targets = await storage.getAllRenewalTargets();
        res.json(targets);
      }
    } catch (error) {
      console.error("Error fetching renewal targets:", error);
      res.status(500).json({ message: "Failed to fetch renewal targets" });
    }
  });

  app.post('/api/renewal-targets', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const { insertRenewalTargetSchema } = await import("@shared/schema");
      const validatedData = insertRenewalTargetSchema.parse(req.body);
      const target = await storage.createRenewalTarget(validatedData);
      res.status(201).json(target);
    } catch (error) {
      console.error("Error creating renewal target:", error);
      res.status(500).json({ message: "Failed to create renewal target" });
    }
  });

  app.put('/api/renewal-targets/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const { insertRenewalTargetSchema } = await import("@shared/schema");
      const id = parseInt(req.params.id);
      const validatedData = insertRenewalTargetSchema.partial().parse(req.body);
      const target = await storage.updateRenewalTarget(id, validatedData);
      res.json(target);
    } catch (error) {
      console.error("Error updating renewal target:", error);
      res.status(500).json({ message: "Failed to update renewal target" });
    }
  });

  app.delete('/api/renewal-targets/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const id = parseInt(req.params.id);
      await storage.deleteRenewalTarget(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting renewal target:", error);
      res.status(500).json({ message: "Failed to delete renewal target" });
    }
  });

  app.get('/api/renewal-targets/analytics/:year', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const year = parseInt(req.params.year);
      const { teamId, salesRepId } = req.query;
      
      const analytics = await storage.getRenewalTargetAnalytics(
        year,
        teamId ? parseInt(teamId as string) : undefined,
        salesRepId as string
      );
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching renewal target analytics:", error);
      res.status(500).json({ message: "Failed to fetch renewal target analytics" });
    }
  });

  // Initialize default teams if they don't exist
  app.post('/api/initialize', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const teams = await storage.getAllTeams();
      if (teams.length === 0) {
        // Create Field Sales Team
        await storage.createTeam({
          name: "Field Sales Team",
          description: "Direct sales team handling face-to-face client interactions",
          customFields: [
            { id: "territory", name: "Territory", type: "select", required: true, options: ["North Region", "South Region", "East Region", "West Region"] },
            { id: "lead_source", name: "Lead Source", type: "select", required: true, options: ["Cold Call", "Referral", "Trade Show", "Website"] }
          ]
        });

        // Create Outbound Team
        await storage.createTeam({
          name: "Outbound Team",
          description: "Remote sales team focused on outbound prospecting",
          customFields: [
            { id: "campaign", name: "Campaign", type: "select", required: true, options: ["Q4 Outreach", "Product Launch", "Holiday Special"] },
            { id: "contact_method", name: "Contact Method", type: "select", required: true, options: ["Email", "Phone", "LinkedIn", "Direct Mail"] }
          ]
        });
      }

      res.json({ message: "Initialization complete" });
    } catch (error) {
      console.error("Error initializing:", error);
      res.status(500).json({ message: "Failed to initialize" });
    }
  });

  // Partnership routes
  app.get('/api/partnerships', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const partnerships = await storage.getAllPartnerships();
      res.json(partnerships);
    } catch (error) {
      console.error("Error fetching partnerships:", error);
      res.status(500).json({ message: "Failed to fetch partnerships" });
    }
  });

  app.post('/api/partnerships', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser || !['admin', 'manager'].includes(currentUser.role)) {
        return res.status(403).json({ message: "Insufficient permissions" });
      }

      const partnershipData = insertPartnershipSchema.parse(req.body);
      const partnership = await storage.createPartnership(partnershipData);
      res.json(partnership);
    } catch (error) {
      console.error("Error creating partnership:", error);
      res.status(500).json({ message: "Failed to create partnership" });
    }
  });

  app.put('/api/partnerships/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser || !['admin', 'manager'].includes(currentUser.role)) {
        return res.status(403).json({ message: "Insufficient permissions" });
      }

      const partnershipId = parseInt(req.params.id);
      const partnershipData = insertPartnershipSchema.partial().parse(req.body);
      const partnership = await storage.updatePartnership(partnershipId, partnershipData);
      res.json(partnership);
    } catch (error) {
      console.error("Error updating partnership:", error);
      res.status(500).json({ message: "Failed to update partnership" });
    }
  });

  app.delete('/api/partnerships/:id', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      if (!currentUser || !['admin', 'manager'].includes(currentUser.role)) {
        return res.status(403).json({ message: "Insufficient permissions" });
      }

      const partnershipId = parseInt(req.params.id);
      await storage.deletePartnership(partnershipId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting partnership:", error);
      res.status(500).json({ message: "Failed to delete partnership" });
    }
  });

  // Banks & PFs routes
  app.get('/api/banks-pfs', isAuthenticated, async (req: any, res) => {
    try {
      // For now, return mock data since we don't have a schema yet
      const mockBanksPFs = [];
      res.json(mockBanksPFs);
    } catch (error) {
      console.error("Error fetching banks & PFs:", error);
      res.status(500).json({ message: "Failed to fetch banks & PFs" });
    }
  });

  // Team Goals API
  app.get("/api/team-goals", isAuthenticated, async (req: any, res) => {
    try {
      const goals = await storage.getAllTeamGoals();
      res.json(goals);
    } catch (error) {
      console.error("Error fetching team goals:", error);
      res.status(500).json({ message: "Failed to fetch team goals" });
    }
  });

  app.post("/api/team-goals", isAuthenticated, async (req: any, res) => {
    try {
      const goalData = req.body;
      
      // For quarterly and yearly goals, check if they already exist and update them
      if (goalData.period === "quarterly" || goalData.period === "yearly") {
        const existingGoals = await storage.getAllTeamGoals();
        const existingGoal = existingGoals.find((g: any) => 
          g.teamId === goalData.teamId &&
          g.salesRepId === goalData.salesRepId &&
          g.goalType === goalData.goalType &&
          g.period === goalData.period &&
          g.startDate === goalData.startDate &&
          g.endDate === goalData.endDate
        );
        
        if (existingGoal) {
          // Calculate new target value by summing related monthly goals
          const relatedMonthlyGoals = existingGoals.filter((g: any) => 
            g.teamId === goalData.teamId &&
            g.salesRepId === goalData.salesRepId &&
            g.goalType === goalData.goalType &&
            g.period === "monthly" &&
            new Date(g.startDate) >= new Date(goalData.startDate) &&
            new Date(g.endDate) <= new Date(goalData.endDate)
          );
          
          const totalTarget = relatedMonthlyGoals.reduce((sum: number, g: any) => 
            sum + parseFloat(g.targetValue), 0
          );
          
          const updatedGoal = await storage.updateTeamGoal(existingGoal.id, {
            targetValue: totalTarget,
            updatedAt: new Date()
          });
          return res.json(updatedGoal);
        }
      }
      
      const goal = await storage.createTeamGoal(goalData);
      res.json(goal);
    } catch (error) {
      console.error("Error creating team goal:", error);
      res.status(500).json({ message: "Failed to create team goal", error: error.message });
    }
  });

  app.put("/api/team-goals/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const goalData = req.body;
      const goal = await storage.updateTeamGoal(parseInt(id), goalData);
      res.json(goal);
    } catch (error) {
      console.error("Error updating team goal:", error);
      res.status(500).json({ message: "Failed to update team goal" });
    }
  });

  app.delete("/api/team-goals/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteTeamGoal(parseInt(id));
      res.json({ message: "Goal deleted successfully" });
    } catch (error) {
      console.error("Error deleting team goal:", error);
      res.status(500).json({ message: "Failed to delete team goal" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

