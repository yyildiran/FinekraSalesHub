import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Handshake, Plus, Building, Users, TrendingUp, Star, Edit, Trash2, Globe, Phone, Mail } from "lucide-react";
import { PartnershipModal } from "@/components/modals/PartnershipModal";
import type { Partnership } from "@shared/schema";

export default function Partnerships() {
  const [partnershipModalOpen, setPartnershipModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: partnerships = [], isLoading } = useQuery<Partnership[]>({
    queryKey: ["/api/partnerships"],
  });

  const deletePartnership = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/partnerships/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        throw new Error("Failed to delete partnership");
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/partnerships"] });
      toast({
        title: "Success",
        description: "Partnership deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete partnership",
        variant: "destructive",
      });
    },
  });

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "active":
        return "default";
      case "inactive":
        return "secondary";
      case "pending":
        return "outline";
      case "terminated":
        return "destructive";
      default:
        return "secondary";
    }
  };

  const getTierIcon = (tier: string | null) => {
    if (!tier) return null;
    switch (tier) {
      case "platinum":
        return <Star className="w-4 h-4 text-purple-600" />;
      case "gold":
        return <Star className="w-4 h-4 text-yellow-600" />;
      case "silver":
        return <Star className="w-4 h-4 text-gray-600" />;
      case "bronze":
        return <Star className="w-4 h-4 text-orange-600" />;
      default:
        return null;
    }
  };

  const activePartnerships = partnerships.filter(p => p.status === "active");
  const channelPartners = partnerships.filter(p => p.partnerType === "channel");
  const technologyPartners = partnerships.filter(p => p.partnerType === "technology");
  const totalRevenue = partnerships.reduce((sum, p) => sum + parseFloat(p.revenueGenerated || "0"), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Partnerships</h1>
          <p className="text-gray-600">Manage strategic partnerships and collaboration opportunities</p>
        </div>
        <Button onClick={() => setPartnershipModalOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Partnership
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Partnerships</CardTitle>
            <Handshake className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activePartnerships.length}</div>
            <p className="text-xs text-muted-foreground">
              {partnerships.length > 0 ? `${activePartnerships.length} of ${partnerships.length} total` : "No partnerships yet"}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Channel Partners</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{channelPartners.length}</div>
            <p className="text-xs text-muted-foreground">Certified resellers</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Technology Partners</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{technologyPartners.length}</div>
            <p className="text-xs text-muted-foreground">Integration partners</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Partner Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₺{totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Total generated</p>
          </CardContent>
        </Card>
      </div>

      {/* Partnerships Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Partnerships</CardTitle>
          <CardDescription>Manage your partnership relationships and track performance</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="text-sm text-muted-foreground">Loading partnerships...</div>
            </div>
          ) : partnerships.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Handshake className="w-12 h-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No partnerships yet</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Start building your partner network by adding your first partnership.
              </p>
              <Button onClick={() => setPartnershipModalOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add First Partnership
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Partner</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Tier</TableHead>
                    <TableHead>Revenue</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {partnerships.map((partnership) => (
                    <TableRow key={partnership.id}>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                            <Building className="w-4 h-4 text-blue-600" />
                          </div>
                          <div>
                            <div className="font-medium">{partnership.partnerName}</div>
                            {partnership.website && (
                              <div className="text-sm text-muted-foreground flex items-center">
                                <Globe className="w-3 h-3 mr-1" />
                                <a
                                  href={partnership.website}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="hover:underline"
                                >
                                  {partnership.website}
                                </a>
                              </div>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {partnership.partnerType}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(partnership.status)} className="capitalize">
                          {partnership.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          {getTierIcon(partnership.partnerTier)}
                          <span className="capitalize">{partnership.partnerTier || "—"}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        ${parseFloat(partnership.revenueGenerated || "0").toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {partnership.contactEmail && (
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Mail className="w-3 h-3 mr-1" />
                              <a
                                href={`mailto:${partnership.contactEmail}`}
                                className="hover:underline"
                              >
                                {partnership.contactEmail}
                              </a>
                            </div>
                          )}
                          {partnership.contactPhone && (
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Phone className="w-3 h-3 mr-1" />
                              <a
                                href={`tel:${partnership.contactPhone}`}
                                className="hover:underline"
                              >
                                {partnership.contactPhone}
                              </a>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deletePartnership.mutate(partnership.id)}
                            disabled={deletePartnership.isPending}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <PartnershipModal
        open={partnershipModalOpen}
        onOpenChange={setPartnershipModalOpen}
      />
    </div>
  );
}