import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Target, Edit, Trash2, Plus, DollarSign, TrendingUp, Calendar } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertRenewalTargetSchema } from "@shared/schema";
import type { RenewalTarget, Team, User } from "@shared/schema";
import { z } from "zod";

const renewalTargetFormSchema = insertRenewalTargetSchema.extend({
  year: z.number().int().min(2020).max(2030),
  renewalRevenueTarget: z.union([z.string(), z.number(), z.null(), z.undefined()]).transform(val => 
    val !== null && val !== undefined ? val.toString() : null
  ).optional(),
  renewalCountTarget: z.number().int().min(0).optional(),
});

type RenewalTargetFormData = z.infer<typeof renewalTargetFormSchema>;

export default function AnnualTargets() {
  const [isTargetModalOpen, setIsTargetModalOpen] = useState(false);
  const [editingTarget, setEditingTarget] = useState<any>(null);
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const targetForm = useForm<RenewalTargetFormData>({
    resolver: zodResolver(renewalTargetFormSchema),
    defaultValues: {
      year: selectedYear,
      teamId: undefined,
      salesRepId: undefined,
      renewalRevenueTarget: undefined,
      renewalCountTarget: undefined,
    },
  });

  const { data: renewalTargets, isLoading: targetsLoading } = useQuery<any[]>({
    queryKey: ["/api/renewal-targets", selectedYear],
    queryFn: async () => {
      const response = await fetch(`/api/renewal-targets?year=${selectedYear}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`${response.status}: ${errorText}`);
      }
      
      const data = await response.json();
      return data;
    },
    retry: false,
  });

  const { data: targetAnalytics, isLoading: analyticsLoading } = useQuery<any>({
    queryKey: ["/api/renewal-targets/analytics", selectedYear],
    queryFn: async () => {
      const response = await fetch(`/api/renewal-targets/analytics/${selectedYear}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`${response.status}: ${errorText}`);
      }
      
      const data = await response.json();
      return data;
    },
    retry: false,
  });

  const { data: teams } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
    retry: false,
  });

  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
    retry: false,
  });

  const createTargetMutation = useMutation({
    mutationFn: async (data: RenewalTargetFormData) => {
      return apiRequest("/api/renewal-targets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/renewal-targets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/renewal-targets/analytics"] });
      setIsTargetModalOpen(false);
      setEditingTarget(null);
      targetForm.reset();
      toast({
        title: "Success",
        description: "Annual target created successfully",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) return;
      toast({
        title: "Error",
        description: error.message || "Failed to create target",
        variant: "destructive",
      });
    },
  });

  const updateTargetMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: RenewalTargetFormData }) => {
      return apiRequest(`/api/renewal-targets/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/renewal-targets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/renewal-targets/analytics"] });
      setIsTargetModalOpen(false);
      setEditingTarget(null);
      targetForm.reset();
      toast({
        title: "Success",
        description: "Annual target updated successfully",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) return;
      toast({
        title: "Error",
        description: error.message || "Failed to update target",
        variant: "destructive",
      });
    },
  });

  const deleteTargetMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/renewal-targets/${id}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/renewal-targets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/renewal-targets/analytics"] });
      toast({
        title: "Success",
        description: "Annual target deleted successfully",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) return;
      toast({
        title: "Error",
        description: error.message || "Failed to delete target",
        variant: "destructive",
      });
    },
  });

  const handleEditTarget = (target: any) => {
    setEditingTarget(target);
    targetForm.reset({
      year: target.year,
      teamId: target.teamId,
      salesRepId: target.salesRepId || undefined,
      renewalRevenueTarget: target.renewalRevenueTarget?.toString() || undefined,
      renewalCountTarget: target.renewalCountTarget || undefined,
    });
    setIsTargetModalOpen(true);
  };

  const handleSubmitTarget = (data: RenewalTargetFormData) => {
    if (editingTarget) {
      updateTargetMutation.mutate({ id: editingTarget.id, data });
    } else {
      createTargetMutation.mutate(data);
    }
  };

  const handleDeleteTarget = (id: number) => {
    if (confirm("Are you sure you want to delete this target?")) {
      deleteTargetMutation.mutate(id);
    }
  };

  const getTeamName = (teamId: number) => {
    const team = teams?.find(t => t.id === teamId);
    return team?.name || "Unknown Team";
  };

  const getUserName = (userId: string) => {
    const user = users?.find(u => u.id === userId);
    return user ? `${user.firstName} ${user.lastName}` : user?.email || "Unknown User";
  };

  const calculateProgress = (target: any) => {
    if (!targetAnalytics?.targets) return { revenueProgress: 0, countProgress: 0 };
    
    const analytics = targetAnalytics.targets.find((t: any) => 
      t.teamId === target.teamId && 
      (target.salesRepId ? t.salesRepId === target.salesRepId : !t.salesRepId)
    );
    
    if (!analytics) return { revenueProgress: 0, countProgress: 0 };
    
    const revenueProgress = target.renewalRevenueTarget 
      ? (analytics.actualRevenue / parseFloat(target.renewalRevenueTarget)) * 100 
      : 0;
    const countProgress = target.renewalCountTarget 
      ? (analytics.actualCount / target.renewalCountTarget) * 100 
      : 0;
    
    return { revenueProgress, countProgress };
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Annual Renewal Targets</h3>
          <p className="text-sm text-gray-600 mt-1">Set and track annual renewal performance targets</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(parseInt(value))}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[2023, 2024, 2025, 2026].map((year) => (
                <SelectItem key={year} value={year.toString()}>
                  {year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Dialog open={isTargetModalOpen} onOpenChange={setIsTargetModalOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => { setEditingTarget(null); targetForm.reset(); }}>
                <Plus className="w-4 h-4 mr-2" />
                Add Target
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>
                  {editingTarget ? "Edit Annual Target" : "Add Annual Target"}
                </DialogTitle>
                <DialogDescription>
                  Set renewal targets for teams or individual sales reps
                </DialogDescription>
              </DialogHeader>
              <Form {...targetForm}>
                <form onSubmit={targetForm.handleSubmit(handleSubmitTarget)} className="space-y-4">
                  <FormField
                    control={targetForm.control}
                    name="year"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Year</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            {...field} 
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={targetForm.control}
                    name="teamId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Team</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value?.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select team" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {teams?.map((team) => (
                              <SelectItem key={team.id} value={team.id.toString()}>
                                {team.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={targetForm.control}
                    name="salesRepId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sales Rep (Optional)</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || ""}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select sales rep (optional)" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="">All Team Members</SelectItem>
                            {users?.map((user) => (
                              <SelectItem key={user.id} value={user.id}>
                                {user.firstName} {user.lastName} ({user.email})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={targetForm.control}
                    name="renewalRevenueTarget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Revenue Target</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" placeholder="0.00" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={targetForm.control}
                    name="renewalCountTarget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Renewal Count Target</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="0" 
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setIsTargetModalOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createTargetMutation.isPending || updateTargetMutation.isPending}>
                      {editingTarget ? "Update" : "Create"} Target
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Cards */}
      {targetAnalytics && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue Target</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatCurrency(targetAnalytics.summary?.totalRevenueTarget || 0)}
              </div>
              <p className="text-xs text-muted-foreground">
                Actual: {formatCurrency(targetAnalytics.summary?.totalActualRevenue || 0)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Count Target</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {targetAnalytics.summary?.totalCountTarget || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                Actual: {targetAnalytics.summary?.totalActualCount || 0}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Overall Progress</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {targetAnalytics.summary?.avgProgress ? `${targetAnalytics.summary.avgProgress.toFixed(1)}%` : "0%"}
              </div>
              <p className="text-xs text-muted-foreground">
                Average completion rate
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Targets Table */}
      <Card>
        <CardHeader>
          <CardTitle>Annual Targets for {selectedYear}</CardTitle>
          <CardDescription>
            Manage renewal targets by team and individual sales representatives
          </CardDescription>
        </CardHeader>
        <CardContent>
          {targetsLoading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-12 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          ) : renewalTargets && renewalTargets.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Team</TableHead>
                  <TableHead>Sales Rep</TableHead>
                  <TableHead>Revenue Target</TableHead>
                  <TableHead>Count Target</TableHead>
                  <TableHead>Progress</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {renewalTargets.map((target: any) => {
                  const { revenueProgress, countProgress } = calculateProgress(target);
                  return (
                    <TableRow key={target.id}>
                      <TableCell className="font-medium">
                        {getTeamName(target.teamId)}
                      </TableCell>
                      <TableCell>
                        {target.salesRepId ? getUserName(target.salesRepId) : "All Team Members"}
                      </TableCell>
                      <TableCell>
                        {target.renewalRevenueTarget ? formatCurrency(parseFloat(target.renewalRevenueTarget)) : "—"}
                      </TableCell>
                      <TableCell>
                        {target.renewalCountTarget || "—"}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {target.renewalRevenueTarget && (
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-gray-500">Revenue:</span>
                              <Badge variant={revenueProgress >= 100 ? "default" : revenueProgress >= 75 ? "secondary" : "destructive"}>
                                {revenueProgress.toFixed(1)}%
                              </Badge>
                            </div>
                          )}
                          {target.renewalCountTarget && (
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-gray-500">Count:</span>
                              <Badge variant={countProgress >= 100 ? "default" : countProgress >= 75 ? "secondary" : "destructive"}>
                                {countProgress.toFixed(1)}%
                              </Badge>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center gap-2 justify-end">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditTarget(target)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteTarget(target.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <Target className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No targets set</h3>
              <p className="text-gray-500 mb-4">Get started by creating your first annual target.</p>
              <Button onClick={() => setIsTargetModalOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add First Target
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}