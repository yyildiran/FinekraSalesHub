import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Calendar, Clock, CheckCircle, XCircle, Monitor, Edit, MoreHorizontal } from "lucide-react";

import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDemoSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Demo, Team, User } from "@shared/schema";
import { z } from "zod";

const demoFormSchema = insertDemoSchema.extend({
  demoDate: z.string().min(1, "Demo date is required"),
}).omit({ customData: true }).extend({
  customData: z.record(z.any()).optional().default({}),
});

type DemoFormData = z.infer<typeof demoFormSchema>;

export default function Outbound() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [salesRepFilter, setSalesRepFilter] = useState<string>("all");
  const [clientFilter, setClientFilter] = useState<string>("");
  const [dateFilter, setDateFilter] = useState<string>("");
  const [dateFilterType, setDateFilterType] = useState<"exact" | "month" | "year">("month");
  const [editingDemo, setEditingDemo] = useState<Demo | null>(null);

  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<DemoFormData>({
    resolver: zodResolver(demoFormSchema),
    defaultValues: {
      salesRepId: (user as any)?.teamId === 2 ? (user as any)?.id || "" : "", // Only default to current user if they're in Outbound Team
      teamId: 2, // Always default to Outbound Team for demos
      clientName: "",
      demoDate: "",
      status: "scheduled",
      notes: "",
      customData: {},
    },
  });

  const { data: demos, isLoading: demosLoading } = useQuery<Demo[]>({
    queryKey: ["/api/demos"],
    retry: false,
  });

  const { data: teams } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const createDemoMutation = useMutation({
    mutationFn: async (data: DemoFormData) => {
      console.log("Creating demo with data:", data);
      const response = await fetch("/api/demos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(data) as any,
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("API Error:", response.status, errorText);
        throw new Error(`${response.status}: ${errorText}`);
      }
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/demos"] });
      setIsCreateModalOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Demo created successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        window.location.href = "/api/logout";
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to create demo",
        variant: "destructive",
      });
    },
  });

  const updateDemoMutation = useMutation({
    mutationFn: async (data: { id: number; updateData: Partial<DemoFormData> }) => {
      return apiRequest(`/api/demos/${data.id}`, {
        method: "PATCH",
        body: JSON.stringify(data.updateData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/demos"] });
      setIsCreateModalOpen(false);
      setEditingDemo(null);
      form.reset();
      toast({
        title: "Success",
        description: "Demo updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update demo",
        variant: "destructive",
      });
    },
  });

  const deleteDemoMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/demos/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/demos"] });
      toast({
        title: "Success",
        description: "Demo deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete demo",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: DemoFormData) => {
    if (editingDemo) {
      updateDemoMutation.mutate({ id: editingDemo.id, updateData: data });
    } else {
      createDemoMutation.mutate(data);
    }
  };

  const handleEdit = (demo: Demo) => {
    setEditingDemo(demo);
    form.reset({
      ...demo,
      demoDate: demo.demoDate || "",
    });
    setIsCreateModalOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this demo?")) {
      deleteDemoMutation.mutate(id);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      scheduled: { variant: "secondary" as const, label: "Scheduled", icon: Calendar },
      completed: { variant: "default" as const, label: "Completed", icon: CheckCircle },
      closed: { variant: "default" as const, label: "Closed", icon: CheckCircle },
      lost: { variant: "destructive" as const, label: "Lost", icon: XCircle },
    };
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.scheduled;
    const IconComponent = config.icon;
    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <IconComponent className="w-3 h-3" />
        {config.label}
      </Badge>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getTeamName = (teamId: number) => {
    return teams?.find(t => t.id === teamId)?.name || "Unknown Team";
  };

  const getSalesRepName = (salesRepId: string) => {
    const salesRep = users?.find(u => u.id === salesRepId);
    return salesRep ? `${salesRep.firstName || ""} ${salesRep.lastName || ""}`.trim() || salesRep.email : "Unknown Rep";
  };

  // Filter demos for Outbound Team only (teamId: 2)
  const outboundDemos = demos?.filter((demo) => demo.teamId === 2) || [];
  
  // Apply additional filters
  const filteredDemos = outboundDemos.filter((demo) => {
    if (statusFilter !== "all" && demo.status !== statusFilter) return false;
    if (salesRepFilter !== "all" && demo.salesRepId !== salesRepFilter) return false;
    if (clientFilter && !demo.clientName.toLowerCase().includes(clientFilter.toLowerCase())) return false;
    if (dateFilter) {
      if (dateFilterType === "exact" && demo.demoDate !== dateFilter) return false;
      if (dateFilterType === "month" && !demo.demoDate?.startsWith(dateFilter)) return false;
      if (dateFilterType === "year" && !demo.demoDate?.startsWith(dateFilter)) return false;
    }
    return true;
  });

  const scheduledDemos = outboundDemos.filter(demo => demo.status === "scheduled").length;
  const completedDemos = outboundDemos.filter(demo => demo.status === "completed").length;
  const closedDemos = outboundDemos.filter(demo => demo.status === "closed").length;
  const lostDemos = outboundDemos.filter(demo => demo.status === "lost").length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-end">
        <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Schedule Demo
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>{editingDemo ? "Edit Demo" : "Schedule New Demo"}</DialogTitle>
              <DialogDescription>
                {editingDemo ? "Update the demo information" : "Create a new demo appointment for the Outbound team"}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="clientName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Client Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter client name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="demoDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Demo Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {(user as any)?.role !== "sales_rep" && (
                  <FormField
                    control={form.control}
                    name="salesRepId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sales Representative</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select sales rep" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {users?.filter(u => u.role === "sales_rep" && u.teamId === 2).map((salesRep) => (
                              <SelectItem key={salesRep.id} value={salesRep.id}>
                                {`${salesRep.firstName || ""} ${salesRep.lastName || ""}`.trim() || salesRep.email}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="scheduled">Scheduled</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="closed">Closed</SelectItem>
                          <SelectItem value="lost">Lost</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Additional notes..."
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => {
                    setIsCreateModalOpen(false);
                    setEditingDemo(null);
                    form.reset();
                  }}>
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createDemoMutation.isPending || updateDemoMutation.isPending}
                  >
                    {editingDemo ? "Update" : "Schedule"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Demos</CardTitle>
            <Monitor className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{outboundDemos.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Scheduled</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{scheduledDemos}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedDemos}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Closed Won</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{closedDemos}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex space-x-4">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="scheduled">Scheduled</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
            <SelectItem value="lost">Lost</SelectItem>
          </SelectContent>
        </Select>

        {(user as any)?.role !== "sales_rep" && (
          <Select value={salesRepFilter} onValueChange={setSalesRepFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Filter by sales rep" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sales Reps</SelectItem>
              {users?.filter(u => u.role === "sales_rep" && u.teamId === 2).map((rep) => (
                <SelectItem key={rep.id} value={rep.id}>
                  {`${rep.firstName || ""} ${rep.lastName || ""}`.trim() || rep.email}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        <Input
          placeholder="Filter by client name"
          value={clientFilter}
          onChange={(e) => setClientFilter(e.target.value)}
          className="w-[200px]"
        />

        <Input
          type="date"
          placeholder="Filter by date"
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
          className="w-[180px]"
        />
      </div>

      {/* Demos Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Outbound Demos</CardTitle>
              <CardDescription>Manage and track outbound team demonstrations</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {demosLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-pulse text-gray-500">Loading demos...</div>
            </div>
          ) : filteredDemos.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Sales Rep</TableHead>
                  <TableHead>Demo Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDemos.map((demo) => (
                  <TableRow key={demo.id}>
                    <TableCell className="font-medium">{demo.clientName}</TableCell>
                    <TableCell>{getSalesRepName(demo.salesRepId)}</TableCell>
                    <TableCell>{demo.demoDate ? formatDate(demo.demoDate) : "Not set"}</TableCell>
                    <TableCell>{getStatusBadge(demo.status)}</TableCell>
                    <TableCell className="max-w-xs truncate">{demo.notes || "No notes"}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEdit(demo)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => handleDelete(demo.id)}
                            className="text-red-600"
                          >
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No demos found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}