import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Calendar, Clock, CheckCircle, XCircle, Monitor, Edit, MoreHorizontal } from "lucide-react";

import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDemoSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Demo, Team, User } from "@shared/schema";
import { z } from "zod";


const demoFormSchema = insertDemoSchema.extend({
  demoDate: z.string().min(1, "Demo date is required"),
}).omit({ customData: true }).extend({
  customData: z.record(z.any()).optional().default({}),
});

type DemoFormData = z.infer<typeof demoFormSchema>;

export default function Demos() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const [salesRepFilter, setSalesRepFilter] = useState<string>("all");
  const [clientFilter, setClientFilter] = useState<string>("");
  const [dateFilter, setDateFilter] = useState<string>("");
  const [dateFilterType, setDateFilterType] = useState<"exact" | "month" | "year">("month");

  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<DemoFormData>({
    resolver: zodResolver(demoFormSchema),
    defaultValues: {
      salesRepId: (user as any)?.teamId === 2 ? (user as any)?.id || "" : "", // Only default to current user if they're in Outbound Team
      teamId: 2, // Always default to Outbound Team for demos
      clientName: "",
      demoDate: "",
      status: "scheduled",
      notes: "",
      customData: {},
    },
  });

  const { data: demos, isLoading: demosLoading } = useQuery<Demo[]>({
    queryKey: ["/api/demos"],
    retry: false,

  });

  const { data: teams } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });



  const createDemoMutation = useMutation({
    mutationFn: async (data: DemoFormData) => {
      console.log("Creating demo with data:", data);
      const response = await fetch("/api/demos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(data) as any,
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("API Error:", response.status, errorText);
        throw new Error(`${response.status}: ${errorText}`);
      }
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/demos"] });
      setIsCreateModalOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Demo created successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create demo",
        variant: "destructive",
      });
    },
  });

  const updateDemoStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      return await apiRequest(`/api/demos/${id}`, {
        method: "PUT",
        body: JSON.stringify({ status }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/demos"] });
      toast({
        title: "Success",
        description: "Demo status updated successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update demo status",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: DemoFormData) => {
    createDemoMutation.mutate(data);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "scheduled":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200"><Clock className="w-3 h-3 mr-1" />Scheduled</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200"><Calendar className="w-3 h-3 mr-1" />Completed</Badge>;
      case "closed":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><CheckCircle className="w-3 h-3 mr-1" />Closed</Badge>;
      case "lost":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200"><XCircle className="w-3 h-3 mr-1" />Lost</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTeamName = (teamId: number) => {
    return teams?.find(t => t.id === teamId)?.name || "Unknown Team";
  };

  const getSalesRepName = (salesRepId: string) => {
    const salesRep = users?.find(u => u.id === salesRepId);
    return salesRep ? `${salesRep.firstName || ""} ${salesRep.lastName || ""}`.trim() || salesRep.email : "Unknown Rep";
  };

  const closedDemos = (demos as any)?.filter((demo: any) => demo.status === "closed") || [];

  // Filter demos based on selected filters
  const filteredDemos = (demos as any)?.filter((demo: any) => {
    if (statusFilter !== "all" && demo.status !== statusFilter) return false;

    if (salesRepFilter !== "all" && demo.salesRepId !== salesRepFilter) return false;
    if (clientFilter && !demo.clientName.toLowerCase().includes(clientFilter.toLowerCase())) return false;
    if (dateFilter) {
      if (dateFilterType === "exact" && demo.demoDate !== dateFilter) return false;
      if (dateFilterType === "month" && !demo.demoDate.startsWith(dateFilter)) return false;
      if (dateFilterType === "year" && !demo.demoDate.startsWith(dateFilter)) return false;
    }
    return true;
  }) || [];



  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-end">
        <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Schedule Demo
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Schedule New Demo</DialogTitle>
              <DialogDescription>
                Create a new demo appointment for a potential client.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="clientName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Client Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter client name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="demoDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Demo Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {(user as any)?.role !== "sales_rep" && (
                  <FormField
                    control={form.control}
                    name="salesRepId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sales Representative</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select sales rep" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {users?.filter(u => u.role === "sales_rep" && u.teamId === 2).map((salesRep) => (
                              <SelectItem key={salesRep.id} value={salesRep.id}>
                                {`${salesRep.firstName || ""} ${salesRep.lastName || ""}`.trim() || salesRep.email}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={form.control}
                  name="teamId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team</FormLabel>
                      <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value?.toString()}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select team" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {teams?.map((team) => (
                            <SelectItem key={team.id} value={team.id.toString()}>
                              {team.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Demo details, client requirements, etc."
                          rows={3}
                          {...field}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsCreateModalOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createDemoMutation.isPending}>
                    {createDemoMutation.isPending ? "Creating..." : "Schedule Demo"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Demos</CardTitle>
            <Monitor className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{(filteredDemos as any)?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Scheduled</CardTitle>
            <Clock className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {(filteredDemos as any)?.filter((d: any) => d.status === "scheduled").length || 0}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <Calendar className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {(filteredDemos as any)?.filter((d: any) => d.status === "completed").length || 0}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Closed Deals</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {(filteredDemos as any)?.filter((d: any) => d.status === "closed").length || 0}
            </div>
          </CardContent>
        </Card>
      </div>



      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filter Demos</CardTitle>
          <CardDescription>Filter demos by status, team, sales rep, client name, or demo date</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="closed">Closed (Sold)</SelectItem>
                  <SelectItem value="lost">Lost</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Sales Rep</label>
              <Select value={salesRepFilter} onValueChange={setSalesRepFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by sales rep" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Reps</SelectItem>
                  {users?.filter(u => u.role === "sales_rep").map((salesRep) => (
                    <SelectItem key={salesRep.id} value={salesRep.id}>
                      {`${salesRep.firstName || ""} ${salesRep.lastName || ""}`.trim() || salesRep.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Client Name</label>
              <Input
                placeholder="Search by client name..."
                value={clientFilter}
                onChange={(e) => setClientFilter(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Date Filter Type</label>
              <Select value={dateFilterType} onValueChange={(value: "exact" | "month" | "year") => {
                setDateFilterType(value);
                setDateFilter(""); // Reset date filter when type changes
              }}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="month">By Month</SelectItem>
                  <SelectItem value="year">By Year</SelectItem>
                  <SelectItem value="exact">Exact Date</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">
                {dateFilterType === "month" ? "Month (YYYY-MM)" : 
                 dateFilterType === "year" ? "Year (YYYY)" : "Demo Date"}
              </label>
              {dateFilterType === "exact" ? (
                <Input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                />
              ) : dateFilterType === "month" ? (
                <Input
                  type="month"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  placeholder="2025-01"
                />
              ) : (
                <Input
                  type="number"
                  min="2020"
                  max="2030"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  placeholder="2025"
                />
              )}
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                setStatusFilter("all");

                setSalesRepFilter("all");
                setClientFilter("");
                setDateFilter("");
                setDateFilterType("month");
              }}
            >
              Clear Filters
            </Button>
            <div className="text-sm text-muted-foreground flex items-center">
              Showing {(filteredDemos as any)?.length || 0} of {(demos as any)?.length || 0} demos
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Demos Table */}
      <Card>
        <CardHeader>
          <CardTitle>Demo List</CardTitle>
          <CardDescription>Manage and track all demo activities</CardDescription>
        </CardHeader>
        <CardContent>
          {demosLoading ? (
            <div>Loading demos...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Sales Rep</TableHead>
                  <TableHead>Team</TableHead>
                  <TableHead>Demo Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(filteredDemos as any)?.map((demo: any) => (
                  <TableRow key={demo.id}>
                    <TableCell className="font-medium">{demo.clientName}</TableCell>
                    <TableCell>{getSalesRepName(demo.salesRepId)}</TableCell>
                    <TableCell>{getTeamName(demo.teamId)}</TableCell>
                    <TableCell>{demo.demoDate}</TableCell>
                    <TableCell>{getStatusBadge(demo.status)}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-[160px]">
                          {demo.status === "scheduled" && (
                            <>
                              <DropdownMenuItem
                                onClick={() => updateDemoStatusMutation.mutate({ id: demo.id, status: "completed" })}
                              >
                                <CheckCircle className="mr-2 h-4 w-4" />
                                Mark Complete
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => updateDemoStatusMutation.mutate({ id: demo.id, status: "closed" })}
                              >
                                <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                                Mark as Sold
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => updateDemoStatusMutation.mutate({ id: demo.id, status: "lost" })}
                              >
                                <XCircle className="mr-2 h-4 w-4 text-red-600" />
                                Mark as Lost
                              </DropdownMenuItem>
                            </>
                          )}
                          {demo.status === "completed" && (
                            <>
                              <DropdownMenuItem
                                onClick={() => updateDemoStatusMutation.mutate({ id: demo.id, status: "closed" })}
                              >
                                <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                                Mark as Sold
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => updateDemoStatusMutation.mutate({ id: demo.id, status: "lost" })}
                              >
                                <XCircle className="mr-2 h-4 w-4 text-red-600" />
                                Mark as Lost
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => updateDemoStatusMutation.mutate({ id: demo.id, status: "scheduled" })}
                              >
                                <Clock className="mr-2 h-4 w-4 text-blue-600" />
                                Back to Scheduled
                              </DropdownMenuItem>
                            </>
                          )}
                          {(demo.status === "closed" || demo.status === "lost") && (
                            <>
                              <DropdownMenuItem
                                onClick={() => updateDemoStatusMutation.mutate({ id: demo.id, status: "completed" })}
                              >
                                <Edit className="mr-2 h-4 w-4" />
                                Back to Complete
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => updateDemoStatusMutation.mutate({ id: demo.id, status: "scheduled" })}
                              >
                                <Clock className="mr-2 h-4 w-4 text-blue-600" />
                                Back to Scheduled
                              </DropdownMenuItem>
                              {demo.status === "lost" && (
                                <DropdownMenuItem
                                  onClick={() => updateDemoStatusMutation.mutate({ id: demo.id, status: "closed" })}
                                >
                                  <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                                  Change to Sold
                                </DropdownMenuItem>
                              )}
                              {demo.status === "closed" && (
                                <DropdownMenuItem
                                  onClick={() => updateDemoStatusMutation.mutate({ id: demo.id, status: "lost" })}
                                >
                                  <XCircle className="mr-2 h-4 w-4 text-red-600" />
                                  Change to Lost
                                </DropdownMenuItem>
                              )}
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
                {(filteredDemos as any)?.length === 0 && demos && (demos as any).length > 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      <div className="text-muted-foreground">
                        <p>No demos match the selected filters</p>
                        <Button 
                          variant="link" 
                          onClick={() => {
                            setStatusFilter("all");
                            setSalesRepFilter("all");
                            setClientFilter("");
                            setDateFilter("");
                            setDateFilterType("month");
                          }}
                          className="mt-2"
                        >
                          Clear filters to see all demos
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
                {(!demos || (demos as any).length === 0) && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      <div className="text-muted-foreground">
                        <p>No demos found</p>
                        <p className="text-sm">Create your first demo to get started</p>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}