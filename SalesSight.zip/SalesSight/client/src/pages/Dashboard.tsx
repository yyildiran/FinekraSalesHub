import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import KPICard from "@/components/KPICard";
import RevenueGoalsChart from "@/components/charts/RevenueGoalsChart";

import { useState } from "react";
import { DollarSign, Handshake, Percent, RotateCcw, CheckCircle } from "lucide-react";
import { formatCurrency, formatPercentage } from "@/lib/utils";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { toast } = useToast();

  const { data: kpis, isLoading: kpisLoading } = useQuery({
    queryKey: ["/api/analytics/kpis"],
    retry: false,
  });

  const { data: recentSales, isLoading: salesLoading } = useQuery({
    queryKey: ["/api/sales"],
    retry: false,
  });

  const { data: upcomingRenewals, isLoading: renewalsLoading } = useQuery({
    queryKey: ["/api/renewals/upcoming"],
    retry: false,
  });

  const { data: banksPFs, isLoading: banksPFsLoading } = useQuery({
    queryKey: ["/api/banks-pfs"],
    retry: false,
  });

  const { data: partnerships, isLoading: partnershipsLoading } = useQuery({
    queryKey: ["/api/partnerships"],
    retry: false,
  });

  if (kpisLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-24"></div>
                  <div className="h-8 bg-gray-200 rounded w-32"></div>
                  <div className="h-3 bg-gray-200 rounded w-20"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }



  return (
    <div className="space-y-6">

      {/* Total Revenue Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {/* Total Revenue with Subsections */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-primary/10 rounded-lg">
                <DollarSign className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-sm font-medium text-gray-600">Total Revenue</CardTitle>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency((kpis as any)?.totalRevenue || 0)}
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-3 gap-4">
              {/* New Sales Revenue */}
              <div className="bg-blue-50 rounded-lg p-3">
                <h4 className="text-xs font-medium text-blue-800 mb-1">New Sales</h4>
                <p className="text-lg font-semibold text-blue-900">
                  {formatCurrency((kpis as any)?.newSalesRevenue || 0)}
                </p>
                <p className="text-xs text-blue-600 mt-1">
                  {((kpis as any)?.newSalesRevenue && (kpis as any)?.totalRevenue) 
                    ? `${Math.round(((kpis as any).newSalesRevenue / (kpis as any).totalRevenue) * 100)}%` 
                    : '0%'} of total
                </p>
              </div>
              
              {/* Renewals Revenue */}
              <div className="bg-green-50 rounded-lg p-3">
                <h4 className="text-xs font-medium text-green-800 mb-1">Renewals</h4>
                <p className="text-lg font-semibold text-green-900">
                  {formatCurrency((kpis as any)?.renewalsRevenue || 0)}
                </p>
                <p className="text-xs text-green-600 mt-1">
                  {((kpis as any)?.renewalsRevenue && (kpis as any)?.totalRevenue) 
                    ? `${Math.round(((kpis as any).renewalsRevenue / (kpis as any).totalRevenue) * 100)}%` 
                    : '0%'} of total
                </p>
              </div>

              {/* Banks & PF's Revenue */}
              <div className="bg-purple-50 rounded-lg p-3">
                <h4 className="text-xs font-medium text-purple-800 mb-1">Banks & PF's</h4>
                <p className="text-lg font-semibold text-purple-900">
                  {formatCurrency((kpis as any)?.banksPFsRevenue || 0)}
                </p>
                <p className="text-xs text-purple-600 mt-1">
                  {((kpis as any)?.banksPFsRevenue && (kpis as any)?.totalRevenue) 
                    ? `${Math.round(((kpis as any).banksPFsRevenue / (kpis as any).totalRevenue) * 100)}%` 
                    : '0%'} of total
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue vs Goals Analysis */}
      <RevenueGoalsChart />

      {/* Recent Activities */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Recent Activities</CardTitle>
            <Button variant="ghost" size="sm">
              View all
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {salesLoading || renewalsLoading || banksPFsLoading || partnershipsLoading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="animate-pulse flex items-center space-x-4 py-3">
                  <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </div>
                  <div className="h-4 bg-gray-200 rounded w-16"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {/* Combine all activities and sort by date */}
              {(() => {
                const allActivities = [];
                
                // Add sales activities
                if (recentSales && (recentSales as any).length > 0) {
                  (recentSales as any).forEach((sale: any) => {
                    allActivities.push({
                      id: `sale-${sale.id}`,
                      type: 'sale',
                      title: sale.status === "closed" ? "Deal closed" : "New sale",
                      description: `with ${sale.clientName}`,
                      amount: formatCurrency(parseFloat(sale.amount)),
                      date: new Date(sale.createdAt),
                      status: sale.status,
                      icon: CheckCircle,
                      iconColor: 'text-green-600',
                      iconBg: 'bg-green-100'
                    });
                  });
                }

                // Add renewal activities
                if (upcomingRenewals && (upcomingRenewals as any).length > 0) {
                  (upcomingRenewals as any).forEach((renewal: any) => {
                    allActivities.push({
                      id: `renewal-${renewal.id}`,
                      type: 'renewal',
                      title: "New renewal",
                      description: `for ${renewal.clientName}`,
                      amount: formatCurrency(parseFloat(renewal.amount || 0)),
                      date: new Date(renewal.createdAt || renewal.dueDate),
                      status: renewal.status,
                      icon: RotateCcw,
                      iconColor: 'text-blue-600',
                      iconBg: 'bg-blue-100'
                    });
                  });
                }

                // Add banks & PFs activities (mock for now - you can replace with actual data)
                if (banksPFs && (banksPFs as any).length > 0) {
                  (banksPFs as any).forEach((bankPF: any) => {
                    allActivities.push({
                      id: `bankpf-${bankPF.id}`,
                      type: 'bankpf',
                      title: "New Banks & PF's deal",
                      description: `with ${bankPF.name || bankPF.clientName}`,
                      amount: formatCurrency(parseFloat(bankPF.amount || 0)),
                      date: new Date(bankPF.createdAt || Date.now()),
                      status: bankPF.status,
                      icon: DollarSign,
                      iconColor: 'text-purple-600',
                      iconBg: 'bg-purple-100'
                    });
                  });
                }

                // Sort by date (most recent first) and take top 5
                return allActivities
                  .sort((a, b) => b.date.getTime() - a.date.getTime())
                  .slice(0, 5)
                  .map((activity) => (
                    <div key={activity.id} className="flex items-center space-x-4 py-3 border-b border-gray-100 last:border-b-0">
                      <div className={`w-10 h-10 ${activity.iconBg} rounded-full flex items-center justify-center`}>
                        <activity.icon className={`h-5 w-5 ${activity.iconColor}`} />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">
                          {activity.title} {activity.description}
                        </p>
                        <p className="text-xs text-gray-600">
                          {activity.amount} • {activity.date.toLocaleDateString()}
                        </p>
                      </div>
                      <Badge variant={activity.status === "closed" || activity.status === "completed" ? "default" : "secondary"}>
                        {activity.amount}
                      </Badge>
                    </div>
                  ));
              })()}
              
              {/* Show message if no activities */}
              {(!recentSales || (recentSales as any).length === 0) && 
               (!upcomingRenewals || (upcomingRenewals as any).length === 0) && 
               (!banksPFs || (banksPFs as any).length === 0) && (
                <div className="text-center py-8 text-gray-500">
                  <p>No recent activities</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>


    </div>
  );
}
