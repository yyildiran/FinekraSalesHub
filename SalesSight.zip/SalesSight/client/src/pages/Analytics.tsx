import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Download } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";




interface TopPerformer {
  salesRepId: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  totalRevenue: number;
  totalSales: number;
}

interface TeamPerformance {
  teamId: number;
  teamName: string;
  totalRevenue: number;
  dealsClosed: number;
  demoCount?: number;
  closedDemos?: number;
}

function FieldSalesTeamCard() {
  const { data: fieldSalesData, isLoading } = useQuery<TeamPerformance>({
    queryKey: ["/api/analytics/team-performance/1"],
    retry: false,
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Field Sales Performance</CardTitle>
        <CardDescription>Key metrics for field sales operations</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="animate-pulse flex justify-between">
                <div className="h-4 bg-gray-300 rounded w-24"></div>
                <div className="h-4 bg-gray-300 rounded w-16"></div>
              </div>
            ))}
          </div>
        ) : fieldSalesData ? (
          <div className="space-y-4">
            <div className="flex justify-between">
              <span className="font-medium">Total Revenue</span>
              <span className="text-green-600 font-semibold">
                ${fieldSalesData.totalRevenue?.toLocaleString() || 0}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Sales Count</span>
              <span className="text-blue-600 font-semibold">
                {fieldSalesData.dealsClosed || 0}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Deals Closed</span>
              <span className="text-indigo-600 font-semibold">
                {fieldSalesData.dealsClosed || 0}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Avg Deal Size</span>
              <span className="text-purple-600 font-semibold">
                ${fieldSalesData.dealsClosed > 0 
                  ? Math.round(fieldSalesData.totalRevenue / fieldSalesData.dealsClosed).toLocaleString()
                  : 0}
              </span>
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <p className="text-sm">No Field Sales data available</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function FieldSalesTopPerformers() {
  const { data: fieldTopPerformers, isLoading: performersLoading } = useQuery({
    queryKey: ["/api/analytics/top-performers/1"],
    retry: false,
  });

  return (
    <div className="space-y-4">
      {performersLoading ? (
        Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="animate-pulse flex items-center justify-between p-2 bg-gray-50 rounded">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-gray-300 rounded-full"></div>
              <div className="h-3 bg-gray-300 rounded w-20"></div>
            </div>
            <div className="h-3 bg-gray-300 rounded w-16"></div>
          </div>
        ))
      ) : Array.isArray(fieldTopPerformers) && fieldTopPerformers.length > 0 ? (
        fieldTopPerformers.slice(0, 3).map((rep: any, index: number) => {
          const displayName = rep.firstName && rep.lastName 
            ? `${rep.firstName} ${rep.lastName}`
            : rep.email 
            ? rep.email.split('@')[0]
            : rep.salesRepId;
          
          return (
            <div key={rep.salesRepId} className="flex items-center justify-between p-2 bg-gray-50 rounded">
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-xs">
                  {index + 1}
                </div>
                <span className="text-sm font-medium text-gray-900">{displayName}</span>
              </div>
              <div className="text-right">
                <span className="text-sm font-semibold text-gray-900">${rep.totalRevenue.toLocaleString()}</span>
                <p className="text-xs text-gray-500">{rep.totalSales} sales</p>
              </div>
            </div>
          );
        })
      ) : (
        <div className="text-center py-4 text-gray-500">
          <p className="text-xs">No field sales data available</p>
        </div>
      )}
    </div>
  );
}

function OutboundTeamCard() {
  const { data: outboundData, isLoading } = useQuery<TeamPerformance>({
    queryKey: ["/api/analytics/team-performance/2"],
    retry: false,
  });

  const { data: outboundTopPerformers, isLoading: performersLoading } = useQuery({
    queryKey: ["/api/analytics/top-performers/2"],
    retry: false,
  });

  const { data: outboundTopDemoTakers, isLoading: demoTakersLoading } = useQuery({
    queryKey: ["/api/analytics/top-demo-takers/2"],
    retry: false,
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Outbound Team Performance</CardTitle>
        <CardDescription>Demo metrics and top performers for outbound prospecting</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="animate-pulse flex justify-between">
                <div className="h-4 bg-gray-300 rounded w-24"></div>
                <div className="h-4 bg-gray-300 rounded w-16"></div>
              </div>
            ))}
          </div>
        ) : outboundData ? (
          <div className="space-y-6">
            {/* Metrics Section */}
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="font-medium">Total Revenue</span>
                <span className="text-green-600 font-semibold">
                  ${outboundData.totalRevenue?.toLocaleString() || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Deals Closed</span>
                <span className="text-blue-600 font-semibold">
                  {outboundData.dealsClosed || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Demo Count</span>
                <span className="text-orange-600 font-semibold">
                  {outboundData.demoCount || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Demos Closing as Sold</span>
                <span className="text-purple-600 font-semibold">
                  {outboundData.closedDemos || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Demo Close Rate</span>
                <span className="text-indigo-600 font-semibold">
                  {(outboundData.demoCount || 0) > 0 
                    ? Math.round((outboundData.closedDemos || 0) / (outboundData.demoCount || 1) * 100)
                    : 0}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Revenue from Demos</span>
                <span className="text-cyan-600 font-semibold">
                  ${outboundData.totalRevenue?.toLocaleString() || 0}
                </span>
              </div>
            </div>

            {/* Top Sales Performers Section */}
            <div className="pt-4 border-t">
              <h4 className="font-medium text-gray-900 mb-3">Top Sales Performers</h4>
              {performersLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="animate-pulse flex items-center justify-between p-2 bg-gray-50 rounded">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 bg-gray-300 rounded-full"></div>
                        <div className="h-3 bg-gray-300 rounded w-20"></div>
                      </div>
                      <div className="h-3 bg-gray-300 rounded w-16"></div>
                    </div>
                  ))}
                </div>
              ) : Array.isArray(outboundTopPerformers) && outboundTopPerformers.length > 0 ? (
                <div className="space-y-2">
                  {outboundTopPerformers.slice(0, 3).map((rep: any, index: number) => {
                    const displayName = rep.firstName && rep.lastName 
                      ? `${rep.firstName} ${rep.lastName}`
                      : rep.email 
                      ? rep.email.split('@')[0]
                      : rep.salesRepId;
                    
                    return (
                      <div key={rep.salesRepId} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <div className="flex items-center space-x-2">
                          <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold text-xs">
                            {index + 1}
                          </div>
                          <span className="text-sm font-medium text-gray-900">{displayName}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-sm font-semibold text-gray-900">${rep.totalRevenue.toLocaleString()}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500">
                  <p className="text-xs">No sales data available</p>
                </div>
              )}
            </div>

            {/* Top Demo Takers Section */}
            <div className="pt-4 border-t">
              <h4 className="font-medium text-gray-900 mb-3">Top Demo Takers</h4>
              {demoTakersLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="animate-pulse flex items-center justify-between p-2 bg-gray-50 rounded">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 bg-gray-300 rounded-full"></div>
                        <div className="h-3 bg-gray-300 rounded w-20"></div>
                      </div>
                      <div className="h-3 bg-gray-300 rounded w-16"></div>
                    </div>
                  ))}
                </div>
              ) : Array.isArray(outboundTopDemoTakers) && outboundTopDemoTakers.length > 0 ? (
                <div className="space-y-2">
                  {outboundTopDemoTakers.slice(0, 3).map((rep: any, index: number) => {
                    const displayName = rep.firstName && rep.lastName 
                      ? `${rep.firstName} ${rep.lastName}`
                      : rep.email 
                      ? rep.email.split('@')[0]
                      : rep.salesRepId;
                    
                    return (
                      <div key={rep.salesRepId} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <div className="flex items-center space-x-2">
                          <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-xs">
                            {index + 1}
                          </div>
                          <span className="text-sm font-medium text-gray-900">{displayName}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-sm font-semibold text-gray-900">{rep.totalDemos} demos</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500">
                  <p className="text-xs">No demo data available</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <p className="text-sm">No Outbound Team data available</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}





export default function Analytics() {
  const { toast } = useToast();







  const handleExport = () => {
    // TODO: Implement export functionality
    console.log("Exporting report...");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-end">
        <Button onClick={handleExport}>
          <Download className="w-4 h-4 mr-2" />
          Export Report
        </Button>
      </div>



      {/* Field Sales Team Analytics */}
      <div className="space-y-6">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-6 bg-blue-600 rounded"></div>
          <h2 className="text-xl font-semibold text-gray-900">Field Sales Team Analytics</h2>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <FieldSalesTeamCard />
          <Card>
            <CardHeader>
              <CardTitle>Field Sales Top Performers</CardTitle>
              <CardDescription>Revenue leaders in field sales</CardDescription>
            </CardHeader>
            <CardContent>
              <FieldSalesTopPerformers />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Outbound Team Analytics */}
      <div className="space-y-6">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-6 bg-orange-600 rounded"></div>
          <h2 className="text-xl font-semibold text-gray-900">Outbound Team Analytics</h2>
        </div>
        <OutboundTeamCard />
      </div>


    </div>
  );
}
