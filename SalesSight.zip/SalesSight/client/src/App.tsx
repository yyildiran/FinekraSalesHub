import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Dashboard from "@/pages/Dashboard";
import FieldSales from "@/pages/FieldSales";
import Outbound from "@/pages/Outbound";
import Renewals from "@/pages/Renewals";
import Partnerships from "@/pages/Partnerships";
import BanksPFs from "@/pages/BanksPFs";
import Analytics from "@/pages/Analytics";

import TeamManagement from "@/pages/TeamManagement";
import UserManagement from "@/pages/UserManagement";

import Layout from "@/components/Layout";
import ProtectedRoute from "@/components/ProtectedRoute";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/">
            {() => (
              <ProtectedRoute>
                <Layout>
                  <Dashboard />
                </Layout>
              </ProtectedRoute>
            )}
          </Route>
          <Route path="/field-sales">
            {() => (
              <ProtectedRoute>
                <Layout>
                  <FieldSales />
                </Layout>
              </ProtectedRoute>
            )}
          </Route>
          <Route path="/outbound">
            {() => (
              <ProtectedRoute>
                <Layout>
                  <Outbound />
                </Layout>
              </ProtectedRoute>
            )}
          </Route>
          <Route path="/renewals">
            {() => (
              <ProtectedRoute>
                <Layout>
                  <Renewals />
                </Layout>
              </ProtectedRoute>
            )}
          </Route>
          <Route path="/banks-pfs">
            {() => (
              <ProtectedRoute>
                <Layout>
                  <BanksPFs />
                </Layout>
              </ProtectedRoute>
            )}
          </Route>
          <Route path="/analytics">
            {() => (
              <ProtectedRoute>
                <Layout>
                  <Analytics />
                </Layout>
              </ProtectedRoute>
            )}
          </Route>

          <Route path="/teams">
            {() => (
              <ProtectedRoute requiredRole="manager">
                <Layout>
                  <TeamManagement />
                </Layout>
              </ProtectedRoute>
            )}
          </Route>
          <Route path="/users">
            {() => (
              <ProtectedRoute requiredRole="admin">
                <Layout>
                  <UserManagement />
                </Layout>
              </ProtectedRoute>
            )}
          </Route>

          <Route path="/partnerships">
            {() => (
              <ProtectedRoute>
                <Layout>
                  <Partnerships />
                </Layout>
              </ProtectedRoute>
            )}
          </Route>

        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
