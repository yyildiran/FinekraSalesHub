import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, X } from "lucide-react";

interface DateRangeFilterProps {
  onDateRangeChange: (startDate: string, endDate: string, filterType: "range" | "month" | "year") => void;
  onClear: () => void;
  className?: string;
  title?: string;
}

export default function DateRangeFilter({ 
  onDateRangeChange, 
  onClear, 
  className = "",
  title = "Date Filter" 
}: DateRangeFilterProps) {
  const [filterType, setFilterType] = useState<"range" | "month" | "year">("range");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [monthFilter, setMonthFilter] = useState("");
  const [yearFilter, setYearFilter] = useState("");

  const handleApplyFilter = () => {
    if (filterType === "range" && startDate && endDate) {
      onDateRangeChange(startDate, endDate, "range");
    } else if (filterType === "month" && monthFilter) {
      // Convert month (YYYY-MM) to start and end dates
      const year = monthFilter.split('-')[0];
      const month = monthFilter.split('-')[1];
      const start = `${year}-${month}-01`;
      const end = new Date(parseInt(year), parseInt(month), 0).toISOString().split('T')[0];
      onDateRangeChange(start, end, "month");
    } else if (filterType === "year" && yearFilter) {
      // Convert year to start and end dates
      const start = `${yearFilter}-01-01`;
      const end = `${yearFilter}-12-31`;
      onDateRangeChange(start, end, "year");
    }
  };

  const handleClear = () => {
    setStartDate("");
    setEndDate("");
    setMonthFilter("");
    setYearFilter("");
    onClear();
  };

  const isFilterApplied = () => {
    return (filterType === "range" && startDate && endDate) ||
           (filterType === "month" && monthFilter) ||
           (filterType === "year" && yearFilter);
  };

  return (
    <Card className={`bg-white border-gray-200 ${className}`}>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium text-gray-700 flex items-center">
          <Calendar className="w-4 h-4 mr-2" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Select value={filterType} onValueChange={(value: "range" | "month" | "year") => setFilterType(value)}>
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="range">Date Range</SelectItem>
              <SelectItem value="month">By Month</SelectItem>
              <SelectItem value="year">By Year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {filterType === "range" && (
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-600 mb-1 block">From</label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="text-sm"
              />
            </div>
            <div>
              <label className="text-xs text-gray-600 mb-1 block">To</label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="text-sm"
              />
            </div>
          </div>
        )}

        {filterType === "month" && (
          <div>
            <label className="text-xs text-gray-600 mb-1 block">Month</label>
            <Input
              type="month"
              value={monthFilter}
              onChange={(e) => setMonthFilter(e.target.value)}
              className="text-sm"
              placeholder="YYYY-MM"
            />
          </div>
        )}

        {filterType === "year" && (
          <div>
            <label className="text-xs text-gray-600 mb-1 block">Year</label>
            <Input
              type="number"
              min="2020"
              max="2030"
              value={yearFilter}
              onChange={(e) => setYearFilter(e.target.value)}
              className="text-sm"
              placeholder="YYYY"
            />
          </div>
        )}

        <div className="flex gap-2">
          <Button 
            onClick={handleApplyFilter}
            disabled={!isFilterApplied()}
            size="sm"
            className="flex-1"
          >
            Apply Filter
          </Button>
          <Button 
            onClick={handleClear}
            variant="outline"
            size="sm"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}