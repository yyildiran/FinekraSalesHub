import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";
import { LucideIcon } from "lucide-react";

interface KPICardProps {
  title: string;
  value: string | number;
  change?: number;
  description?: string;
  icon: LucideIcon;
  iconColor: string;
  iconBg: string;
}

export default function KPICard({
  title,
  value,
  change,
  description,
  icon: Icon,
  iconColor,
  iconBg,
}: KPICardProps) {
  const formatChange = (change: number) => {
    const isPositive = change >= 0;
    return (
      <span className={`text-sm ${isPositive ? "text-green-600" : "text-red-600"} flex items-center`}>
        {isPositive ? (
          <TrendingUp className="w-3 h-3 mr-1" />
        ) : (
          <TrendingDown className="w-3 h-3 mr-1" />
        )}
        {Math.abs(change)}% from last month
      </span>
    );
  };

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-2xl font-bold text-gray-900">{value}</p>
            {change !== undefined ? (
              formatChange(change)
            ) : description ? (
              <p className="text-sm text-gray-600 mt-1">{description}</p>
            ) : null}
          </div>
          <div className={`w-12 h-12 ${iconBg} rounded-lg flex items-center justify-center`}>
            <Icon className={`${iconColor} text-lg w-5 h-5`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
