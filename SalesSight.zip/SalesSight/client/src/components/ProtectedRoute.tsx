import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: "admin" | "manager" | "sales_rep" | "viewer";
}

export default function ProtectedRoute({ children, requiredRole }: ProtectedRouteProps) {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }

    if (!isLoading && isAuthenticated && requiredRole && user?.role !== requiredRole) {
      if (requiredRole === "admin" && !["admin"].includes(user?.role || "")) {
        toast({
          title: "Access Denied",
          description: "Admin access required.",
          variant: "destructive",
        });
        return;
      }
      if (requiredRole === "manager" && !["admin", "manager"].includes(user?.role || "")) {
        toast({
          title: "Access Denied",
          description: "Manager access required.",
          variant: "destructive",
        });
        return;
      }
    }
  }, [isAuthenticated, isLoading, user, requiredRole, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return <>{children}</>;
}
