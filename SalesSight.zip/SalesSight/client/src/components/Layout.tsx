import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { 
  LayoutDashboard, 
  Plus, 
  RotateCcw, 
  Monitor,
  BarChart3, 
  Settings,
  Users,
  UserCog,
  Target,
  Handshake,
  LogOut,
  Download,
  ChevronDown
} from "lucide-react";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location, navigate] = useLocation();
  const { user } = useAuth();

  if (!user) {
    return null;
  }

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const mainTabs = [
    { value: "dashboard", label: "Dashboard", path: "/", icon: LayoutDashboard },
    { value: "field-sales", label: "Field Sales", path: "/field-sales", icon: Target },
    { value: "outbound", label: "Outbound", path: "/outbound", icon: Monitor },
    { value: "renewals", label: "Renewals", path: "/renewals", icon: RotateCcw },
    { value: "partnerships", label: "Partnerships", path: "/partnerships", icon: Handshake },
    { value: "banks-pfs", label: "Banks & PF's", path: "/banks-pfs", icon: Users },
    { value: "analytics", label: "Analytics", path: "/analytics", icon: BarChart3 },
    { value: "settings", label: "Settings", path: "/settings", icon: Settings },
  ];

  const getCurrentTab = () => {
    if (location === "/" || location === "/dashboard") return "dashboard";
    if (location === "/field-sales") return "field-sales";
    if (location === "/outbound") return "outbound";
    if (location === "/renewals") return "renewals";
    if (location === "/partnerships") return "partnerships";
    if (location === "/banks-pfs") return "banks-pfs";
    if (location === "/analytics") return "analytics";
    if (location.startsWith("/teams") || location.startsWith("/users") || location.startsWith("/settings")) return "settings";
    return "dashboard";
  };

  const handleTabChange = (value: string) => {
    const tab = mainTabs.find(t => t.value === value);
    if (tab) {
      if (value === "settings") {
        // Default to team management for settings
        navigate("/teams");
      } else {
        navigate(tab.path);
      }
    }
  };

  const getPageTitle = () => {
    switch (location) {
      case "/":
      case "/dashboard":
        return "Dashboard Overview";
      case "/field-sales":
        return "Field Sales Pipeline";
      case "/outbound":
        return "Outbound Demos";
      case "/renewals":
        return "Renewals Management";
      case "/partnerships":
        return "Partnerships";
      case "/banks-pfs":
        return "Banks & Private Funds";
      case "/analytics":
        return "Performance Analytics";
      case "/teams":
        return "Team Management";
      case "/users":
        return "User Management";
      default:
        return "Sales Management";
    }
  };

  const getPageDescription = () => {
    switch (location) {
      case "/":
      case "/dashboard":
        return "Overview of sales performance and key metrics";
      case "/field-sales":
        return "Manage field sales opportunities and pipeline";
      case "/outbound":
        return "Schedule and track outbound team demonstrations";
      case "/renewals":
        return "Track contract renewals and manage renewal opportunities";
      case "/partnerships":
        return "Manage strategic partnerships and collaboration opportunities";
      case "/banks-pfs":
        return "Manage banking and private fund relationships";
      case "/analytics":
        return "Comprehensive insights into sales performance";
      case "/teams":
        return "Configure teams and custom fields";
      case "/users":
        return "Manage user accounts and permissions";
      default:
        return "";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold text-gray-900">Sales Management</h1>
              <p className="text-sm text-gray-500 mt-1">Welcome back, {(user as any)?.firstName || (user as any)?.email || 'User'}</p>
            </div>
            <div className="flex items-center gap-3">
              {/* Quick Actions Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Quick Actions
                    <ChevronDown className="w-4 h-4 ml-2" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={() => navigate("/field-sales")}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add New Sale
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate("/renewals")}>
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Add Renewal
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate("/outbound")}>
                    <Monitor className="w-4 h-4 mr-2" />
                    Schedule Demo
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate("/partnerships")}>
                    <Handshake className="w-4 h-4 mr-2" />
                    Add Partnership
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>

        {/* Main Navigation Tabs */}
        <div className="px-6">
          <Tabs value={getCurrentTab()} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid w-full grid-cols-8 bg-gray-50">
              {mainTabs.map((tab) => (
                <TabsTrigger
                  key={tab.value}
                  value={tab.value}
                  className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm"
                >
                  <tab.icon className="w-4 h-4" />
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>

        {/* Settings Sub-navigation */}
        {getCurrentTab() === "settings" && (
          <div className="px-6 py-3 bg-gray-50 border-t border-gray-100">
            <div className="flex gap-4">
              <Button
                variant={location === "/teams" ? "default" : "ghost"}
                size="sm"
                onClick={() => navigate("/teams")}
                className="flex items-center gap-2"
              >
                <Users className="w-4 h-4" />
                Team Management
              </Button>
              <Button
                variant={location === "/users" ? "default" : "ghost"}
                size="sm"
                onClick={() => navigate("/users")}
                className="flex items-center gap-2"
              >
                <UserCog className="w-4 h-4" />
                User Management
              </Button>
            </div>
          </div>
        )}
      </header>

      {/* Page Header */}
      <div className="bg-white border-b border-gray-100">
        <div className="px-6 py-4">
          <h2 className="text-2xl font-semibold text-gray-900">{getPageTitle()}</h2>
          {getPageDescription() && (
            <p className="text-gray-600 mt-1">{getPageDescription()}</p>
          )}
        </div>
      </div>

      {/* Main Content */}
      <main className="px-6 py-6">
        {children}
      </main>
    </div>
  );
}