import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { useState } from "react";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";

export default function RevenueChart() {
  const [timeframe, setTimeframe] = useState("6");
  const { toast } = useToast();

  const { data: revenueData, isLoading: revenueLoading } = useQuery({
    queryKey: ["/api/analytics/revenue", timeframe],
    queryFn: () => {
      const params = new URLSearchParams();
      params.append('months', timeframe);
      
      const url = `/api/analytics/revenue?${params.toString()}`;
      return fetch(url).then(res => res.json());
    },
    retry: false,
  });

  const { data: goalsData, isLoading: goalsLoading } = useQuery({
    queryKey: ["/api/team-goals"],
    retry: false,
  });

  // Process chart data combining revenue and goals
  const processChartData = () => {
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    // Create a map for revenue data by month
    const revenueByMonth: Record<string, number> = {};
    if (revenueData && Array.isArray(revenueData)) {
      revenueData.forEach((item: any) => {
        if (item.month) {
          const date = new Date(item.month);
          const monthName = monthNames[date.getMonth()];
          revenueByMonth[monthName] = parseFloat(item.revenue) || 0;
        }
      });
    }
    
    // Create a map for goals data by month
    const goalsByMonth: Record<string, number> = {};
    if (goalsData && Array.isArray(goalsData)) {
      goalsData.forEach((goal: any) => {
        if (goal.goalType === 'revenue' && goal.period === 'monthly' && goal.startDate) {
          const date = new Date(goal.startDate);
          const monthName = monthNames[date.getMonth()];
          goalsByMonth[monthName] = (goalsByMonth[monthName] || 0) + (parseFloat(goal.targetValue) || 0);
        }
      });
    }
    
    // Get last 6 months
    const currentDate = new Date();
    const last6Months = [];
    for (let i = 5; i >= 0; i--) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
      const monthName = monthNames[date.getMonth()];
      last6Months.push({
        month: monthName,
        revenue: revenueByMonth[monthName] || 0,
        goal: goalsByMonth[monthName] || 0,
      });
    }
    
    return last6Months;
  };

  const chartData = processChartData();
  const isLoading = revenueLoading || goalsLoading;

  const formatCurrency = (value: number) => {
    return `₺${(value / 1000000).toFixed(1)}M`;
  };

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-900">Revenue Trend</CardTitle>
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="6">Last 6 months</SelectItem>
              <SelectItem value="12">Last 12 months</SelectItem>
              <SelectItem value="24">Last 2 years</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis 
                  dataKey="month" 
                  stroke="#666"
                  fontSize={12}
                />
                <YAxis 
                  tickFormatter={formatCurrency}
                  stroke="#666"
                  fontSize={12}
                />
                <Tooltip 
                  formatter={(value: number, name: string) => [
                    formatCurrency(value), 
                    name === 'revenue' ? 'Revenue' : 'Goal'
                  ]}
                  labelStyle={{ color: "#666" }}
                />
                <Legend />
                <Bar 
                  dataKey="revenue" 
                  fill="#1976D2"
                  radius={[4, 4, 0, 0]}
                  name="Revenue"
                />
                <Bar 
                  dataKey="goal" 
                  fill="#FF6B35"
                  radius={[4, 4, 0, 0]}
                  name="Goal"
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
