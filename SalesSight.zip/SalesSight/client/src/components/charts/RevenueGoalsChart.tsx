import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { useState } from "react";

export default function RevenueGoalsChart() {
  const [selectedPeriod, setSelectedPeriod] = useState("monthly");

  const { data: revenueData, isLoading: revenueLoading } = useQuery({
    queryKey: ["/api/analytics/revenue"],
    queryFn: () => fetch("/api/analytics/revenue?months=12").then(res => res.json()),
    retry: false,
  });

  const { data: goalsData, isLoading: goalsLoading } = useQuery({
    queryKey: ["/api/team-goals"],
    retry: false,
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency: 'TRY',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatCurrencyShort = (value: number) => {
    if (value >= 1000000) {
      return `₺${(value / 1000000).toFixed(1)}M`;
    } else if (value >= 1000) {
      return `₺${(value / 1000).toFixed(0)}K`;
    }
    return `₺${value}`;
  };

  // Process monthly data
  const processMonthlyData = () => {
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    // Create revenue map by month
    const revenueByMonth: Record<string, number> = {};
    if (revenueData && Array.isArray(revenueData)) {
      revenueData.forEach((item: any) => {
        if (item.month) {
          const date = new Date(item.month);
          const monthName = monthNames[date.getMonth()];
          revenueByMonth[monthName] = parseFloat(item.revenue) || 0;
        }
      });
    }
    
    // Create goals map by month
    const goalsByMonth: Record<string, number> = {};
    if (goalsData && Array.isArray(goalsData)) {
      goalsData.forEach((goal: any) => {
        if (goal.goalType === 'revenue' && goal.period === 'monthly' && goal.startDate) {
          const date = new Date(goal.startDate);
          const monthName = monthNames[date.getMonth()];
          goalsByMonth[monthName] = (goalsByMonth[monthName] || 0) + (parseFloat(goal.targetValue) || 0);
        }
      });
    }
    
    // Get months from January to current month
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth(); // 0-based (0 = January, 11 = December)
    
    const monthsFromJanuary = [];
    for (let i = 0; i <= currentMonth; i++) {
      const monthName = monthNames[i];
      monthsFromJanuary.push({
        period: monthName,
        revenue: revenueByMonth[monthName] || 0,
        goal: goalsByMonth[monthName] || 0,
      });
    }
    
    return monthsFromJanuary;
  };

  // Process quarterly data
  const processQuarterlyData = () => {
    const currentYear = new Date().getFullYear();
    const quarters = ['Q1', 'Q2', 'Q3', 'Q4'];
    
    // Create revenue map by quarter
    const revenueByQuarter: Record<string, number> = { Q1: 0, Q2: 0, Q3: 0, Q4: 0 };
    if (revenueData && Array.isArray(revenueData)) {
      revenueData.forEach((item: any) => {
        if (item.month) {
          const date = new Date(item.month);
          const month = date.getMonth() + 1;
          const quarter = Math.ceil(month / 3);
          const quarterKey = `Q${quarter}`;
          revenueByQuarter[quarterKey] += parseFloat(item.revenue) || 0;
        }
      });
    }
    
    // Create goals map by quarter
    const goalsByQuarter: Record<string, number> = { Q1: 0, Q2: 0, Q3: 0, Q4: 0 };
    if (goalsData && Array.isArray(goalsData)) {
      goalsData.forEach((goal: any) => {
        if (goal.goalType === 'revenue' && goal.period === 'quarterly' && goal.startDate) {
          const date = new Date(goal.startDate);
          const month = date.getMonth() + 1;
          const quarter = Math.ceil(month / 3);
          const quarterKey = `Q${quarter}`;
          goalsByQuarter[quarterKey] += parseFloat(goal.targetValue) || 0;
        }
      });
    }
    
    return quarters.map(quarter => ({
      period: quarter,
      revenue: revenueByQuarter[quarter],
      goal: goalsByQuarter[quarter],
    }));
  };

  // Process yearly data
  const processYearlyData = () => {
    const currentYear = new Date().getFullYear();
    const years = [currentYear - 2, currentYear - 1, currentYear];
    
    // Create revenue map by year
    const revenueByYear: Record<number, number> = {};
    if (revenueData && Array.isArray(revenueData)) {
      revenueData.forEach((item: any) => {
        if (item.month) {
          const date = new Date(item.month);
          const year = date.getFullYear();
          revenueByYear[year] = (revenueByYear[year] || 0) + (parseFloat(item.revenue) || 0);
        }
      });
    }
    
    // Create goals map by year
    const goalsByYear: Record<number, number> = {};
    if (goalsData && Array.isArray(goalsData)) {
      goalsData.forEach((goal: any) => {
        if (goal.goalType === 'revenue' && goal.period === 'yearly' && goal.startDate) {
          const date = new Date(goal.startDate);
          const year = date.getFullYear();
          goalsByYear[year] = (goalsByYear[year] || 0) + (parseFloat(goal.targetValue) || 0);
        }
      });
    }
    
    return years.map(year => ({
      period: year.toString(),
      revenue: revenueByYear[year] || 0,
      goal: goalsByYear[year] || 0,
    }));
  };

  const getChartData = () => {
    switch (selectedPeriod) {
      case 'monthly':
        return processMonthlyData();
      case 'quarterly':
        return processQuarterlyData();
      case 'yearly':
        return processYearlyData();
      default:
        return processMonthlyData();
    }
  };

  const chartData = getChartData();
  const isLoading = revenueLoading || goalsLoading;

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">Revenue vs Goals Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={selectedPeriod} onValueChange={setSelectedPeriod}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
            <TabsTrigger value="quarterly">Quarterly</TabsTrigger>
            <TabsTrigger value="yearly">Yearly</TabsTrigger>
          </TabsList>
          
          <TabsContent value="monthly" className="mt-6">
            <div className="h-80">
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis 
                      dataKey="period" 
                      stroke="#666"
                      fontSize={12}
                    />
                    <YAxis 
                      tickFormatter={formatCurrencyShort}
                      stroke="#666"
                      fontSize={12}
                    />
                    <Tooltip 
                      formatter={(value: number, name: string) => [
                        formatCurrency(value), 
                        name === 'revenue' ? 'Revenue' : 'Goal'
                      ]}
                      labelStyle={{ color: "#666" }}
                    />
                    <Legend />
                    <Bar 
                      dataKey="revenue" 
                      fill="#1976D2"
                      radius={[4, 4, 0, 0]}
                      name="Revenue"
                    />
                    <Bar 
                      dataKey="goal" 
                      fill="#FF6B35"
                      radius={[4, 4, 0, 0]}
                      name="Goal"
                    />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="quarterly" className="mt-6">
            <div className="h-80">
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis 
                      dataKey="period" 
                      stroke="#666"
                      fontSize={12}
                    />
                    <YAxis 
                      tickFormatter={formatCurrencyShort}
                      stroke="#666"
                      fontSize={12}
                    />
                    <Tooltip 
                      formatter={(value: number, name: string) => [
                        formatCurrency(value), 
                        name === 'revenue' ? 'Revenue' : 'Goal'
                      ]}
                      labelStyle={{ color: "#666" }}
                    />
                    <Legend />
                    <Bar 
                      dataKey="revenue" 
                      fill="#1976D2"
                      radius={[4, 4, 0, 0]}
                      name="Revenue"
                    />
                    <Bar 
                      dataKey="goal" 
                      fill="#FF6B35"
                      radius={[4, 4, 0, 0]}
                      name="Goal"
                    />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="yearly" className="mt-6">
            <div className="h-80">
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis 
                      dataKey="period" 
                      stroke="#666"
                      fontSize={12}
                    />
                    <YAxis 
                      tickFormatter={formatCurrencyShort}
                      stroke="#666"
                      fontSize={12}
                    />
                    <Tooltip 
                      formatter={(value: number, name: string) => [
                        formatCurrency(value), 
                        name === 'revenue' ? 'Revenue' : 'Goal'
                      ]}
                      labelStyle={{ color: "#666" }}
                    />
                    <Legend />
                    <Bar 
                      dataKey="revenue" 
                      fill="#1976D2"
                      radius={[4, 4, 0, 0]}
                      name="Revenue"
                    />
                    <Bar 
                      dataKey="goal" 
                      fill="#FF6B35"
                      radius={[4, 4, 0, 0]}
                      name="Goal"
                    />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}