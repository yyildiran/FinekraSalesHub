import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useState } from "react";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";

export default function TeamChart() {
  const [selectedTeam, setSelectedTeam] = useState("field");
  const { toast } = useToast();

  const { data: performanceData, isLoading } = useQuery({
    queryKey: ["/api/analytics/team-performance"],
    retry: false,
  });

  // Transform the API data for the chart
  const transformDataForChart = (data: any[]) => {
    return data.map(item => ({
      name: item.firstName && item.lastName ? `${item.firstName} ${item.lastName}` : 
            item.email ? item.email.split('@')[0] : 
            item.salesRepId || 'Unknown Rep',
      deals: parseInt(item.totalSales) || 0,
      revenue: parseFloat(item.totalRevenue) || 0,
    }));
  };

  const chartData = Array.isArray(performanceData) && performanceData.length > 0 ? transformDataForChart(performanceData) : [];

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-900">Team Performance</CardTitle>
          <div className="flex space-x-2">
            <Button
              size="sm"
              variant={selectedTeam === "field" ? "default" : "outline"}
              onClick={() => setSelectedTeam("field")}
            >
              Field Sales
            </Button>
            <Button
              size="sm"
              variant={selectedTeam === "outbound" ? "default" : "outline"}
              onClick={() => setSelectedTeam("outbound")}
            >
              Outbound
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis 
                  dataKey="name" 
                  stroke="#666"
                  fontSize={12}
                />
                <YAxis 
                  stroke="#666"
                  fontSize={12}
                />
                <Tooltip 
                  formatter={(value: number, name: string) => [
                    name === "deals" ? value : `$${value.toLocaleString()}`, 
                    name === "deals" ? "Deals Closed" : "Revenue"
                  ]}
                  labelStyle={{ color: "#666" }}
                />
                <Bar 
                  dataKey="deals" 
                  fill="#388E3C" 
                  radius={[6, 6, 0, 0]}
                  name="deals"
                />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              <div className="text-center">
                <p className="text-sm">No team performance data available yet</p>
                <p className="text-xs mt-1">Data will appear once sales are assigned to team members</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
