import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useQuery } from "@tanstack/react-query";
import * as z from "zod";

const teamGoalSchema = z.object({
  teamId: z.number(),
  salesRepId: z.string().optional().nullable(),
  goalType: z.enum(["revenue", "sales_count", "demo_count", "conversion_rate"]),
  monthlyTarget: z.number().min(0),
  targetMonth: z.string().regex(/^\d{2}-\d{4}$/, "Please use MM-YYYY format"),
  description: z.string().optional(),
});

type TeamGoalForm = z.infer<typeof teamGoalSchema>;

interface TeamGoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: TeamGoalForm) => Promise<void>;
  goal?: any;
}

export default function TeamGoalModal({ isOpen, onClose, onSubmit, goal }: TeamGoalModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: teams } = useQuery({
    queryKey: ["/api/teams"],
    retry: false,
  });

  const { data: users } = useQuery({
    queryKey: ["/api/users"],
    retry: false,
  });

  // Helper function to convert date to MM-YYYY format
  const dateToMonthYear = (dateStr: string) => {
    const date = new Date(dateStr);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}-${year}`;
  };

  // Helper function to get current month-year
  const getCurrentMonthYear = () => {
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    return `${month}-${year}`;
  };

  // Helper function to get next month-year
  const getNextMonthYear = () => {
    const now = new Date();
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const month = String(nextMonth.getMonth() + 1).padStart(2, '0');
    const year = nextMonth.getFullYear();
    return `${month}-${year}`;
  };

  const form = useForm<TeamGoalForm>({
    resolver: zodResolver(teamGoalSchema),
    defaultValues: goal ? {
      teamId: goal.teamId,
      salesRepId: goal.salesRepId || null,
      goalType: goal.goalType,
      monthlyTarget: parseFloat(goal.targetValue),
      targetMonth: goal.startDate ? dateToMonthYear(goal.startDate) : getCurrentMonthYear(),
      description: goal.description || "",
    } : {
      teamId: 1,
      salesRepId: null,
      goalType: "revenue",
      monthlyTarget: 0,
      targetMonth: getCurrentMonthYear(),
      description: "",
    },
  });

  const selectedTeamId = form.watch("teamId");
  const teamUsers = Array.isArray(users) ? users.filter((user: any) => user.teamId === selectedTeamId) : [];

  // Helper function to convert MM-YYYY to date
  const monthYearToDate = (monthYear: string, isEndDate: boolean = false) => {
    const [month, year] = monthYear.split('-');
    if (isEndDate) {
      // For end date, use last day of the month
      const lastDay = new Date(parseInt(year), parseInt(month), 0).getDate();
      return `${year}-${month}-${String(lastDay).padStart(2, '0')}`;
    } else {
      // For start date, use first day of the month
      return `${year}-${month}-01`;
    }
  };

  const handleSubmit = async (data: TeamGoalForm) => {
    setIsSubmitting(true);
    try {
      const [month, year] = data.targetMonth.split('-');
      const startDate = `${year}-${month}-01`;
      const lastDay = new Date(parseInt(year), parseInt(month), 0).getDate();
      const endDate = `${year}-${month}-${String(lastDay).padStart(2, '0')}`;
      
      // Create monthly goal
      const monthlyGoal = {
        teamId: data.teamId,
        salesRepId: data.salesRepId === "all" ? null : data.salesRepId,
        goalType: data.goalType,
        targetValue: data.monthlyTarget,
        period: "monthly",
        startDate,
        endDate,
        description: data.description,
      };
      
      await onSubmit(monthlyGoal);
      
      // Create or update quarterly goal
      const quarterStartMonth = Math.floor((parseInt(month) - 1) / 3) * 3 + 1;
      const quarterStartDate = `${year}-${String(quarterStartMonth).padStart(2, '0')}-01`;
      const quarterEndMonth = quarterStartMonth + 2;
      const quarterEndLastDay = new Date(parseInt(year), quarterEndMonth, 0).getDate();
      const quarterEndDate = `${year}-${String(quarterEndMonth).padStart(2, '0')}-${String(quarterEndLastDay).padStart(2, '0')}`;
      
      const quarterlyGoal = {
        teamId: data.teamId,
        salesRepId: data.salesRepId === "all" ? null : data.salesRepId,
        goalType: data.goalType,
        targetValue: data.monthlyTarget, // Same as monthly for now, will be updated by aggregation
        period: "quarterly",
        startDate: quarterStartDate,
        endDate: quarterEndDate,
        description: `Q${Math.ceil(parseInt(month) / 3)} ${year} - Sum of monthly goals`,
      };
      
      await onSubmit(quarterlyGoal);
      
      // Create or update yearly goal
      const yearStartDate = `${year}-01-01`;
      const yearEndDate = `${year}-12-31`;
      
      const yearlyGoal = {
        teamId: data.teamId,
        salesRepId: data.salesRepId === "all" ? null : data.salesRepId,
        goalType: data.goalType,
        targetValue: data.monthlyTarget, // Same as monthly for now, will be updated by aggregation
        period: "yearly",
        startDate: yearStartDate,
        endDate: yearEndDate,
        description: `${year} Annual Goal - Sum of monthly goals`,
      };
      
      await onSubmit(yearlyGoal);
      
      form.reset();
    } catch (error) {
      console.error("Error submitting goal:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const goalTypeLabels = {
    revenue: "Revenue Target",
    sales_count: "Sales Count",
    demo_count: "Demo Count",
    conversion_rate: "Conversion Rate (%)",
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{goal ? "Edit Monthly Goal" : "Create Monthly Goal"}</DialogTitle>
          <DialogDescription>
            Enter monthly targets. System auto-creates quarterly and yearly goals by summing monthly entries.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="teamId">Team</Label>
              <Select 
                value={form.watch("teamId")?.toString()} 
                onValueChange={(value) => form.setValue("teamId", parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select team" />
                </SelectTrigger>
                <SelectContent>
                  {Array.isArray(teams) && teams.map((team: any) => (
                    <SelectItem key={team.id} value={team.id.toString()}>
                      {team.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="salesRepId">Team Member (Optional)</Label>
              <Select 
                value={form.watch("salesRepId") || "all"} 
                onValueChange={(value) => form.setValue("salesRepId", value === "all" ? null : value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All team members" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All team members</SelectItem>
                  {teamUsers.map((user: any) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.firstName && user.lastName 
                        ? `${user.firstName} ${user.lastName}` 
                        : user.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="goalType">Goal Type</Label>
              <Select 
                value={form.watch("goalType")} 
                onValueChange={(value) => form.setValue("goalType", value as any)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select goal type" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(goalTypeLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="targetMonth">Target Month</Label>
              <Input
                id="targetMonth"
                type="text"
                placeholder="MM-YYYY (e.g., 01-2025)"
                {...form.register("targetMonth")}
              />
              {form.formState.errors.targetMonth && (
                <p className="text-sm text-red-500">{form.formState.errors.targetMonth.message}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="monthlyTarget">
              Monthly Target {form.watch("goalType") === "revenue" ? "(₺)" : ""}
            </Label>
            <Input
              type="number"
              step={form.watch("goalType") === "conversion_rate" ? "0.1" : "1"}
              min="0"
              placeholder="Enter monthly target value"
              {...form.register("monthlyTarget", { valueAsNumber: true })}
            />
            <p className="text-sm text-muted-foreground">
              System will auto-create quarterly and yearly goals by summing monthly entries
            </p>
          </div>



          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              placeholder="Describe the goal and context..."
              {...form.register("description")}
            />
          </div>

          <div className="flex justify-end space-x-3">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Saving..." : goal ? "Update Goal" : "Create Goal"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}