import { useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertRenewalSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

interface RenewalModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingData?: any;
}

export default function RenewalModal({ isOpen, onClose, editingData }: RenewalModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm({
    resolver: zodResolver(insertRenewalSchema.partial()),
    defaultValues: {
      renewalAmount: "",
      renewalDate: "",
      status: "pending" as const,
      notes: "",
    },
  });

  useEffect(() => {
    if (editingData) {
      form.reset({
        renewalAmount: editingData.renewalAmount || "",
        renewalDate: editingData.renewalDate || "",
        status: editingData.status || "pending",
        notes: editingData.notes || "",
      });
    } else {
      form.reset({
        renewalAmount: "",
        renewalDate: "",
        status: "pending",
        notes: "",
      });
    }
  }, [editingData, form]);

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      if (!editingData) {
        throw new Error("Renewal editing data is required");
      }
      const response = await apiRequest("PUT", `/api/renewals/${editingData.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/renewals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/renewals/upcoming"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/kpis"] });
      onClose();
      toast({
        title: "Success",
        description: "Renewal updated successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update renewal",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    const renewalData = {
      ...data,
      renewalAmount: data.renewalAmount ? parseFloat(data.renewalAmount) : null,
    };
    mutation.mutate(renewalData);
  };

  if (!editingData) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Update Renewal</DialogTitle>
          <DialogDescription>
            Update renewal information for {editingData.clientName}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* Display original sale info */}
            <div className="bg-gray-50 p-4 rounded-lg space-y-2">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium text-gray-700">Client:</span>
                  <p>{editingData.clientName}</p>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Original Amount:</span>
                  <p>${parseFloat(editingData.originalAmount).toLocaleString()}</p>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Original Close Date:</span>
                  <p>{new Date(editingData.originalCloseDate).toLocaleDateString()}</p>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Expiry Date:</span>
                  <p>{new Date(editingData.expiryDate).toLocaleDateString()}</p>
                </div>
              </div>
            </div>

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="renewed">Renewed</SelectItem>
                      <SelectItem value="lost">Lost</SelectItem>
                      <SelectItem value="expired">Expired</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="renewalAmount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Renewal Amount (optional)</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-gray-500">₺</span>
                      <Input 
                        {...field} 
                        type="number" 
                        step="0.01"
                        className="pl-8" 
                        placeholder="0,00" 
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="renewalDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Renewal Date (optional)</FormLabel>
                  <FormControl>
                    <Input {...field} type="date" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Add any notes about this renewal..."
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending ? "Updating..." : "Update Renewal"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
