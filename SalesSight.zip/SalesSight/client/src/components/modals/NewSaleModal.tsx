import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertSaleSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useAuth } from "@/hooks/useAuth";
import DynamicForm from "@/components/DynamicForm";
import { z } from "zod";

interface NewSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingData?: any;
}

export default function NewSaleModal({ isOpen, onClose, editingData }: NewSaleModalProps) {
  const [selectedTeam, setSelectedTeam] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const { data: teams } = useQuery({
    queryKey: ["/api/teams"],
    retry: false,
  });

  const { data: users } = useQuery({
    queryKey: ["/api/users"],
    retry: false,
  });

  const extendedSchema = insertSaleSchema.extend({
    teamId: z.number().min(1, "Team is required"),
  });

  const form = useForm({
    resolver: zodResolver(extendedSchema),
    defaultValues: {
      salesRepId: user?.id || "",
      teamId: undefined as number | undefined,
      clientName: "",
      amount: "",
      closeDate: "",
      customData: {},
      status: "pending" as const,
    },
  });

  useEffect(() => {
    if (editingData) {
      form.reset({
        salesRepId: editingData.salesRepId,
        teamId: editingData.teamId,
        clientName: editingData.clientName,
        amount: editingData.amount,
        closeDate: editingData.closeDate,
        customData: editingData.customData || {},
        status: editingData.status,
      });
      const team = teams?.find((t: any) => t.id === editingData.teamId);
      setSelectedTeam(team);
    } else {
      form.reset({
        salesRepId: user?.id || "",
        teamId: undefined,
        clientName: "",
        amount: "",
        closeDate: "",
        customData: {},
        status: "pending",
      });
      setSelectedTeam(null);
    }
  }, [editingData, teams, user, form]);

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      const url = editingData ? `/api/sales/${editingData.id}` : "/api/sales";
      const method = editingData ? "PUT" : "POST";
      const response = await apiRequest(method, url, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/renewals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/kpis"] });
      onClose();
      toast({
        title: "Success",
        description: `Sale ${editingData ? "updated" : "created"} successfully`,
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: `Failed to ${editingData ? "update" : "create"} sale`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    const saleData = {
      ...data,
      amount: parseFloat(data.amount),
      customData: selectedTeam ? form.getValues("customData") : {},
    };
    mutation.mutate(saleData);
  };

  const handleTeamChange = (teamId: string) => {
    const team = teams?.find((t: any) => t.id === parseInt(teamId));
    setSelectedTeam(team);
    form.setValue("teamId", parseInt(teamId));
    form.setValue("customData", {});
  };

  const salesReps = users?.filter((u: any) => 
    u.role === "sales_rep" || u.role === "manager" || u.role === "admin"
  ) || [];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editingData ? "Edit Sale" : "Add New Sale"}</DialogTitle>
          <DialogDescription>
            {editingData ? "Update the sale information" : "Enter the details for the new sale"}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Team Selection */}
            <FormField
              control={form.control}
              name="teamId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Team</FormLabel>
                  <Select 
                    value={field.value?.toString()} 
                    onValueChange={handleTeamChange}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select Team" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {teams?.map((team: any) => (
                        <SelectItem key={team.id} value={team.id.toString()}>
                          {team.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Basic Sale Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="salesRepId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sales Rep</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Sales Rep" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {salesReps.map((rep: any) => (
                          <SelectItem key={rep.id} value={rep.id}>
                            {rep.firstName} {rep.lastName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deal Amount</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <span className="absolute left-3 top-2 text-gray-500">$</span>
                        <Input 
                          {...field} 
                          type="number" 
                          step="0.01"
                          className="pl-8" 
                          placeholder="0.00" 
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="clientName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Client Name</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Client company name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="closeDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Close Date</FormLabel>
                    <FormControl>
                      <Input {...field} type="date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {editingData && (
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="closed">Closed</SelectItem>
                        <SelectItem value="lost">Lost</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Dynamic Team-Specific Fields */}
            {selectedTeam && selectedTeam.customFields && selectedTeam.customFields.length > 0 && (
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-gray-900 border-t pt-4">
                  {selectedTeam.name} Specific Fields
                </h4>
                <DynamicForm
                  fields={selectedTeam.customFields}
                  data={form.getValues("customData")}
                  onChange={(data) => form.setValue("customData", data)}
                />
              </div>
            )}

            <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending ? "Saving..." : editingData ? "Update Sale" : "Add Sale"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
