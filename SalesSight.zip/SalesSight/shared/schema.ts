import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  date,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth and app users
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role", { enum: ["admin", "manager", "sales_rep", "viewer"] }).notNull().default("viewer"),
  teamId: integer("team_id").references(() => teams.id),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Teams with dynamic field configuration
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  customFields: jsonb("custom_fields").$type<Array<{
    id: string;
    name: string;
    type: "text" | "select" | "number" | "date";
    required: boolean;
    options?: string[];
  }>>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Sales records with dynamic team-specific data
export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  salesRepId: varchar("sales_rep_id").notNull().references(() => users.id),
  teamId: integer("team_id").notNull().references(() => teams.id),
  clientName: varchar("client_name").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  closeDate: date("close_date").notNull(),
  customData: jsonb("custom_data").$type<Record<string, any>>().default({}),
  status: varchar("status", { enum: ["pending", "closed", "lost"] }).notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Partnerships
export const partnerships = pgTable("partnerships", {
  id: serial("id").primaryKey(),
  partnerName: varchar("partner_name").notNull(),
  partnerType: varchar("partner_type", { enum: ["channel", "technology", "strategic"] }).notNull().default("channel"),
  contactEmail: varchar("contact_email"),
  contactPhone: varchar("contact_phone"),
  status: varchar("status", { enum: ["active", "inactive", "pending", "terminated"] }).notNull().default("active"),
  partnerTier: varchar("partner_tier", { enum: ["bronze", "silver", "gold", "platinum"] }),
  description: text("description"),
  website: varchar("website"),
  revenueGenerated: decimal("revenue_generated", { precision: 12, scale: 2 }).default("0"),
  dealsCount: integer("deals_count").default(0),
  contractStartDate: date("contract_start_date"),
  contractEndDate: date("contract_end_date"),
  customData: jsonb("custom_data").$type<Record<string, any>>().default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Contract renewals
export const renewals = pgTable("renewals", {
  id: serial("id").primaryKey(),
  saleId: integer("sale_id").notNull().references(() => sales.id),
  clientName: varchar("client_name").notNull(),
  originalAmount: decimal("original_amount", { precision: 12, scale: 2 }).notNull(),
  renewalAmount: decimal("renewal_amount", { precision: 12, scale: 2 }),
  originalCloseDate: date("original_close_date").notNull(),
  renewalDate: date("renewal_date"),
  expiryDate: date("expiry_date").notNull(),
  status: varchar("status", { enum: ["pending", "renewed", "lost", "expired"] }).notNull().default("pending"),
  salesRepId: varchar("sales_rep_id").notNull().references(() => users.id),
  teamId: integer("team_id").notNull().references(() => teams.id),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Demos table for tracking demo activities
export const demos = pgTable("demos", {
  id: serial("id").primaryKey(),
  salesRepId: varchar("sales_rep_id").notNull().references(() => users.id),
  teamId: integer("team_id").notNull().references(() => teams.id),
  clientName: varchar("client_name").notNull(),
  demoDate: date("demo_date").notNull(),
  status: varchar("status", { enum: ["scheduled", "completed", "closed", "lost"] }).notNull().default("scheduled"),
  notes: text("notes"),
  customData: jsonb("custom_data").$type<Record<string, any>>().default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  team: one(teams, {
    fields: [users.teamId],
    references: [teams.id],
  }),
  sales: many(sales),
  renewals: many(renewals),
  demos: many(demos),
}));

export const teamsRelations = relations(teams, ({ many }) => ({
  users: many(users),
  sales: many(sales),
  renewals: many(renewals),
  demos: many(demos),
}));

export const salesRelations = relations(sales, ({ one, many }) => ({
  salesRep: one(users, {
    fields: [sales.salesRepId],
    references: [users.id],
  }),
  team: one(teams, {
    fields: [sales.teamId],
    references: [teams.id],
  }),
  renewals: many(renewals),
}));

export const renewalsRelations = relations(renewals, ({ one }) => ({
  sale: one(sales, {
    fields: [renewals.saleId],
    references: [sales.id],
  }),
  salesRep: one(users, {
    fields: [renewals.salesRepId],
    references: [users.id],
  }),
  team: one(teams, {
    fields: [renewals.teamId],
    references: [teams.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  firstName: true,
  lastName: true,
  role: true,
  teamId: true,
});

export const upsertUserSchema = createInsertSchema(users).pick({
  id: true,
  email: true,
  firstName: true,
  lastName: true,
  profileImageUrl: true,
});

export const insertTeamSchema = createInsertSchema(teams).pick({
  name: true,
  description: true,
  customFields: true,
});

export const insertSaleSchema = createInsertSchema(sales).pick({
  salesRepId: true,
  teamId: true,
  clientName: true,
  amount: true,
  closeDate: true,
  customData: true,
  status: true,
}).extend({
  amount: z.union([z.string(), z.number()]).transform(val => val.toString()),
});

export const insertRenewalSchema = createInsertSchema(renewals).pick({
  saleId: true,
  clientName: true,
  originalAmount: true,
  renewalAmount: true,
  originalCloseDate: true,
  renewalDate: true,
  expiryDate: true,
  status: true,
  salesRepId: true,
  teamId: true,
  notes: true,
}).extend({
  originalAmount: z.union([z.string(), z.number()]).transform(val => val.toString()),
  renewalAmount: z.union([z.string(), z.number(), z.null(), z.undefined()]).transform(val => 
    val !== null && val !== undefined ? val.toString() : null
  ).optional(),
});

export const insertDemoSchema = createInsertSchema(demos).pick({
  salesRepId: true,
  teamId: true,
  clientName: true,
  demoDate: true,
  status: true,
  notes: true,
  customData: true,
});

export const insertPartnershipSchema = createInsertSchema(partnerships).pick({
  partnerName: true,
  partnerType: true,
  contactEmail: true,
  contactPhone: true,
  status: true,
  partnerTier: true,
  description: true,
  website: true,
  revenueGenerated: true,
  dealsCount: true,
  contractStartDate: true,
  contractEndDate: true,
  customData: true,
}).extend({
  contactEmail: z.string().optional().nullable(),
  contactPhone: z.string().optional().nullable(),
  partnerTier: z.string().optional().nullable(),
  description: z.string().optional().nullable(),
  website: z.string().optional().nullable(),
  contractStartDate: z.string().optional().nullable(),
  contractEndDate: z.string().optional().nullable(),
  revenueGenerated: z.union([z.string(), z.number(), z.null(), z.undefined()]).transform(val => 
    val !== null && val !== undefined ? val.toString() : "0"
  ).optional(),
});

// Types
export type User = typeof users.$inferSelect;
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Team = typeof teams.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Sale = typeof sales.$inferSelect;
export type InsertSale = z.infer<typeof insertSaleSchema>;
export type Renewal = typeof renewals.$inferSelect;
export type InsertRenewal = z.infer<typeof insertRenewalSchema>;
export type Partnership = typeof partnerships.$inferSelect;
export type InsertPartnership = z.infer<typeof insertPartnershipSchema>;

export const demosRelations = relations(demos, ({ one }) => ({
  salesRep: one(users, {
    fields: [demos.salesRepId],
    references: [users.id],
  }),
  team: one(teams, {
    fields: [demos.teamId],
    references: [teams.id],
  }),
}));

// Renewal targets table
export const renewalTargets = pgTable("renewal_targets", {
  id: serial("id").primaryKey(),
  year: integer("year").notNull(),
  teamId: integer("team_id").references(() => teams.id),
  salesRepId: varchar("sales_rep_id").references(() => users.id),
  renewalCountTarget: integer("renewal_count_target"),
  renewalRevenueTarget: decimal("renewal_revenue_target", { precision: 12, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const renewalTargetsRelations = relations(renewalTargets, ({ one }) => ({
  team: one(teams, {
    fields: [renewalTargets.teamId],
    references: [teams.id],
  }),
  salesRep: one(users, {
    fields: [renewalTargets.salesRepId],
    references: [users.id],
  }),
}));

// Team goals table for performance tracking
export const teamGoals = pgTable("team_goals", {
  id: serial("id").primaryKey(),
  teamId: integer("team_id").notNull().references(() => teams.id),
  salesRepId: varchar("sales_rep_id").references(() => users.id), // null means team-wide goal
  goalType: varchar("goal_type", { enum: ["revenue", "sales_count", "demo_count", "conversion_rate"] }).notNull(),
  targetValue: decimal("target_value", { precision: 12, scale: 2 }).notNull(),
  currentValue: decimal("current_value", { precision: 12, scale: 2 }).notNull().default("0"),
  period: varchar("period", { enum: ["monthly", "quarterly", "yearly"] }).notNull().default("monthly"),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  description: text("description"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const teamGoalsRelations = relations(teamGoals, ({ one }) => ({
  team: one(teams, {
    fields: [teamGoals.teamId],
    references: [teams.id],
  }),
  salesRep: one(users, {
    fields: [teamGoals.salesRepId],
    references: [users.id],
  }),
}));

export const insertRenewalTargetSchema = createInsertSchema(renewalTargets).pick({
  year: true,
  teamId: true,
  salesRepId: true,
  renewalCountTarget: true,
  renewalRevenueTarget: true,
}).extend({
  renewalRevenueTarget: z.union([z.string(), z.number(), z.null(), z.undefined()]).transform(val => 
    val !== null && val !== undefined ? val.toString() : null
  ).optional(),
});

export type Demo = typeof demos.$inferSelect;
export type InsertDemo = z.infer<typeof insertDemoSchema>;
export type RenewalTarget = typeof renewalTargets.$inferSelect;
export type InsertRenewalTarget = z.infer<typeof insertRenewalTargetSchema>;

export const insertTeamGoalSchema = createInsertSchema(teamGoals).pick({
  teamId: true,
  salesRepId: true,
  goalType: true,
  targetValue: true,
  currentValue: true,
  period: true,
  startDate: true,
  endDate: true,
  description: true,
  isActive: true,
}).extend({
  targetValue: z.union([z.string(), z.number()]).transform(val => val.toString()),
  currentValue: z.union([z.string(), z.number()]).transform(val => val.toString()).optional(),
});

export type TeamGoal = typeof teamGoals.$inferSelect;
export type InsertTeamGoal = z.infer<typeof insertTeamGoalSchema>;

export type TeamField = {
  id: string;
  name: string;
  type: "text" | "select" | "number" | "date";
  required: boolean;
  options?: string[];
};
